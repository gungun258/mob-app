
  # Complete mobile application

  This is a code bundle for Complete mobile application. The original project is available at https://www.figma.com/design/E4awMWyLbmCxG8SXgxCB3m/Complete-mobile-application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  