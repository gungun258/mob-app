import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Mail, MessageCircle, Phone } from 'lucide-react';
import Input from '../components/Input';
import Button from '../components/Button';
import Card from '../components/Card';

export default function Support() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/account');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Contact Support</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 gap-3">
          <Card hoverable className="p-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-2xl">
                <Mail className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-800">Email Us</h3>
                <p className="text-sm text-gray-600">support@aiphotostudio.com</p>
              </div>
            </div>
          </Card>

          <Card hoverable className="p-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-green-100 to-emerald-100 rounded-2xl">
                <MessageCircle className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-800">Live Chat</h3>
                <p className="text-sm text-gray-600">Available 9 AM - 6 PM EST</p>
              </div>
            </div>
          </Card>

          <Card hoverable className="p-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl">
                <Phone className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-800">Phone Support</h3>
                <p className="text-sm text-gray-600">+1 (800) 123-4567</p>
              </div>
            </div>
          </Card>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">Send us a message</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Subject"
              type="text"
              placeholder="What do you need help with?"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
              <textarea
                placeholder="Describe your issue in detail..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={6}
                className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-rose-300 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all placeholder:text-gray-400"
              />
            </div>

            <div className="pt-4">
              <Button type="submit" fullWidth size="lg">
                Send Message
              </Button>
            </div>
          </form>
        </div>

        <Card className="p-6 bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200">
          <h4 className="font-bold text-gray-800 mb-2">Response Time</h4>
          <p className="text-sm text-gray-700">
            We typically respond within 24 hours. For urgent issues, please use live chat during business hours.
          </p>
        </Card>
      </div>
    </div>
  );
}
