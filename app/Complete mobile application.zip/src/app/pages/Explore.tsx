import { useEffect } from 'react';
import { useNavigate } from 'react-router';

export default function Explore() {
  const navigate = useNavigate();

  useEffect(() => {
    navigate('/discover', { replace: true });
  }, [navigate]);

  return null;
}
