import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { Search, SlidersHorizontal, Star, ChevronRight } from 'lucide-react';
import Card from '../components/Card';

const sellers = [
  {
    id: 1,
    name: "Sarah's Studio",
    description: 'Professional nature & landscape backgrounds',
    listings: 156,
    rating: 4.9,
    reviews: 234,
    following: true,
    sampleListings: [
      { id: 1, title: 'Sunset Beach' },
      { id: 2, title: 'Mountain Vista' },
      { id: 3, title: 'Ocean Waves' },
    ],
  },
  {
    id: 2,
    name: 'AI Art Pro',
    description: 'AI-generated abstract & modern backgrounds',
    listings: 234,
    rating: 4.9,
    reviews: 412,
    following: true,
    sampleListings: [
      { id: 4, title: 'Neon Dreams' },
      { id: 5, title: 'Digital Space' },
      { id: 6, title: 'Abstract Flow' },
    ],
  },
  {
    id: 3,
    name: 'Creative Minds',
    description: 'Urban & street photography backgrounds',
    listings: 89,
    rating: 4.8,
    reviews: 156,
    following: false,
    sampleListings: [
      { id: 7, title: 'City Lights' },
      { id: 8, title: 'Urban Night' },
      { id: 9, title: 'Street Art' },
    ],
  },
  {
    id: 4,
    name: 'Photo Masters',
    description: 'Vintage & retro styled backgrounds',
    listings: 127,
    rating: 4.7,
    reviews: 203,
    following: false,
    sampleListings: [
      { id: 10, title: 'Retro Vibes' },
      { id: 11, title: 'Vintage Film' },
      { id: 12, title: 'Old School' },
    ],
  },
];

const categories = ['All', 'Nature', 'Urban', 'Abstract', 'Vintage', 'Modern'];
const sortOptions = ['Top Rated', 'Most Listings', 'Trending', 'Newest'];

export default function AllSellers() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const filter = searchParams.get('filter');

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSort, setSelectedSort] = useState('Top Rated');
  const [followingStatus, setFollowingStatus] = useState<{ [key: number]: boolean }>(
    sellers.reduce((acc, seller) => ({ ...acc, [seller.id]: seller.following }), {})
  );

  const toggleFollow = (sellerId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setFollowingStatus((prev) => ({ ...prev, [sellerId]: !prev[sellerId] }));
  };

  const filteredSellers = filter === 'following'
    ? sellers.filter(s => followingStatus[s.id])
    : filter === 'trending'
    ? sellers.slice(0, 3)
    : sellers;

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-indigo-50/20 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronRight className="w-6 h-6 text-gray-700 rotate-180" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">
              {filter === 'following' ? 'Following' : filter === 'trending' ? 'Trending Sellers' : 'All Sellers'}
            </h1>
            <p className="text-sm text-gray-600">{filteredSellers.length} sellers</p>
          </div>
        </div>

        <div className="flex gap-3 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search sellers..."
              className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-indigo-300 focus:outline-none focus:ring-4 focus:ring-indigo-100/50 transition-all"
            />
          </div>
          <button className="p-3 bg-gray-100 rounded-2xl hover:bg-gray-200 transition-colors">
            <SlidersHorizontal className="w-6 h-6 text-gray-700" />
          </button>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide mb-3">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-lg'
                  : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-indigo-300'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {sortOptions.map((sort) => (
            <button
              key={sort}
              onClick={() => setSelectedSort(sort)}
              className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap transition-all ${
                selectedSort === sort
                  ? 'bg-indigo-100 text-indigo-700 font-medium'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {sort}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-6">
        {filteredSellers.map((seller) => (
          <Card key={seller.id} className="overflow-hidden">
            <div className="p-4">
              <div className="flex items-start gap-4 mb-4">
                <div
                  onClick={() => navigate(`/seller/${seller.id}`)}
                  className="w-16 h-16 bg-gradient-to-br from-indigo-400 via-purple-500 to-pink-500 rounded-xl flex items-center justify-center text-white text-2xl font-bold cursor-pointer"
                >
                  {seller.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <h3
                    onClick={() => navigate(`/seller/${seller.id}`)}
                    className="font-bold text-gray-800 mb-1 cursor-pointer hover:text-indigo-600"
                  >
                    {seller.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-2">{seller.description}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span>{seller.listings} listings</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span className="font-bold text-gray-800">{seller.rating}</span>
                      <span>({seller.reviews})</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={(e) => toggleFollow(seller.id, e)}
                  className={`px-4 py-2 rounded-xl font-medium transition-all ${
                    followingStatus[seller.id]
                      ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      : 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:shadow-lg'
                  }`}
                >
                  {followingStatus[seller.id] ? 'Following' : 'Follow'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3">
                {seller.sampleListings.map((listing) => (
                  <div
                    key={listing.id}
                    onClick={() => navigate(`/product/${listing.id}`)}
                    className="aspect-square bg-gradient-to-br from-cyan-200 via-blue-300 to-purple-300 rounded-xl cursor-pointer hover:scale-105 transition-transform"
                  />
                ))}
              </div>
            </div>

            <button
              onClick={() => navigate(`/seller/${seller.id}`)}
              className="w-full py-3 bg-gray-50 hover:bg-gray-100 transition-colors text-center font-medium text-gray-700 flex items-center justify-center gap-2"
            >
              View All Listings
              <ChevronRight className="w-4 h-4" />
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
}
