import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, ChevronDown, Search } from 'lucide-react';
import Card from '../components/Card';

const faqs = [
  {
    category: 'Getting Started',
    questions: [
      {
        q: 'How do I create my first AI photo?',
        a: 'Simply upload your photo, choose a background from our marketplace, and tap Generate. Our AI will create a stunning combination in seconds!',
      },
      {
        q: 'How many credits do I need?',
        a: 'Each AI generation costs 10 credits. You can buy credit packs or earn free credits through referrals and daily bonuses.',
      },
    ],
  },
  {
    category: 'Credits & Pricing',
    questions: [
      {
        q: 'How do credits work?',
        a: 'Credits are used for AI generations and HD downloads. 1 AI generation = 10 credits, 1 HD download = 5 credits. Credits never expire!',
      },
      {
        q: 'Can I get a refund for credits?',
        a: 'Unused credits can be refunded within 30 days of purchase. Once used for generations, they cannot be refunded.',
      },
    ],
  },
  {
    category: 'Selling',
    questions: [
      {
        q: 'How do I become a seller?',
        a: 'Anyone can sell! Go to your account, tap Seller Dashboard, and post your first ad. We review all listings to ensure quality.',
      },
      {
        q: 'What percentage does the platform take?',
        a: 'We take a 20% commission on all sales. Sellers receive 80% of the listing price directly to their account.',
      },
    ],
  },
];

export default function FAQ() {
  const navigate = useNavigate();
  const [openIndex, setOpenIndex] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleQuestion = (categoryIndex: number, questionIndex: number) => {
    const key = `${categoryIndex}-${questionIndex}`;
    setOpenIndex(openIndex === key ? null : key);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">FAQ</h1>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-rose-300 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all"
          />
        </div>
      </div>

      <div className="p-6 space-y-6">
        {faqs.map((category, categoryIndex) => (
          <div key={categoryIndex}>
            <h2 className="text-lg font-bold text-gray-800 mb-3">{category.category}</h2>
            <div className="space-y-2">
              {category.questions.map((faq, questionIndex) => {
                const key = `${categoryIndex}-${questionIndex}`;
                const isOpen = openIndex === key;

                return (
                  <Card key={questionIndex} className="overflow-hidden">
                    <button
                      onClick={() => toggleQuestion(categoryIndex, questionIndex)}
                      className="w-full flex items-start gap-4 p-4 text-left hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-800">{faq.q}</h3>
                        {isOpen && <p className="mt-3 text-gray-600 leading-relaxed">{faq.a}</p>}
                      </div>
                      <ChevronDown
                        className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform ${
                          isOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                  </Card>
                );
              })}
            </div>
          </div>
        ))}

        <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 text-center">
          <h3 className="font-bold text-gray-800 mb-2">Still have questions?</h3>
          <p className="text-gray-600 text-sm mb-4">Our support team is here to help!</p>
          <button
            onClick={() => navigate('/support')}
            className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl font-medium hover:shadow-lg transition-all"
          >
            Contact Support
          </button>
        </Card>
      </div>
    </div>
  );
}
