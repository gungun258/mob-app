import { useNavigate } from 'react-router';
import { Upload, Image as ImageIcon, Sparkles, ChevronRight } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';

export default function Generate() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <h1 className="text-2xl font-bold text-gray-800">Generate AI Image</h1>
        <p className="text-gray-600 text-sm">Create stunning photos with AI</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-3xl p-8 text-white text-center shadow-xl">
          <div className="inline-block p-4 bg-white/20 backdrop-blur-sm rounded-2xl mb-4">
            <Sparkles className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-bold mb-2">AI Magic Awaits</h2>
          <p className="text-purple-50 mb-6">
            Upload your photo and background to create stunning AI-generated images
          </p>
        </div>

        <Card
          onClick={() => navigate('/upload-photo')}
          hoverable
          className="p-6"
        >
          <div className="flex items-center gap-4">
            <div className="p-4 bg-gradient-to-br from-rose-100 to-pink-100 rounded-2xl">
              <Upload className="w-8 h-8 text-rose-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800 mb-1">Step 1: Upload Your Photo</h3>
              <p className="text-sm text-gray-600">Select a photo from your gallery or take a new one</p>
            </div>
            <ChevronRight className="w-6 h-6 text-gray-400" />
          </div>
        </Card>

        <Card
          onClick={() => navigate('/upload-background')}
          hoverable
          className="p-6"
        >
          <div className="flex items-center gap-4">
            <div className="p-4 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-2xl">
              <ImageIcon className="w-8 h-8 text-purple-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800 mb-1">Step 2: Choose Background</h3>
              <p className="text-sm text-gray-600">Browse marketplace or upload your own</p>
            </div>
            <ChevronRight className="w-6 h-6 text-gray-400" />
          </div>
        </Card>

        <div className="pt-4">
          <Button
            onClick={() => navigate('/ai-processing')}
            fullWidth
            size="lg"
          >
            <Sparkles className="w-5 h-5" />
            Generate AI Image
          </Button>
        </div>

        <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 border-2 border-amber-200">
          <h3 className="font-bold text-gray-800 mb-2">Quick Tips</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500">•</span>
              <span>Use clear, well-lit photos for best results</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500">•</span>
              <span>Choose backgrounds that match your photo's style</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500">•</span>
              <span>Each generation uses 10 credits</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
