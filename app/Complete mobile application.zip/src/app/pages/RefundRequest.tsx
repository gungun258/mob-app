import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, Upload } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';

const reasons = [
  'Product not as described',
  'Technical issue with download',
  'Poor quality',
  'Changed my mind',
  'Other',
];

export default function RefundRequest() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [selectedReason, setSelectedReason] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/orders');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Request Refund</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Card className="p-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 rounded-xl" />
            <div className="flex-1">
              <h3 className="font-bold text-gray-800">Sunset Beach Background</h3>
              <p className="text-sm text-gray-600">Ordered on May 7, 2026</p>
              <p className="text-rose-600 font-bold mt-1">$15.00</p>
            </div>
          </div>
        </Card>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Reason for Refund
            </label>
            <div className="space-y-2">
              {reasons.map((reason) => (
                <button
                  key={reason}
                  type="button"
                  onClick={() => setSelectedReason(reason)}
                  className={`w-full text-left px-4 py-3 rounded-2xl border-2 transition-all ${
                    selectedReason === reason
                      ? 'bg-gradient-to-r from-rose-50 to-pink-50 border-rose-300 font-medium'
                      : 'bg-white border-gray-200 hover:border-rose-200'
                  }`}
                >
                  {reason}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Additional Details
            </label>
            <textarea
              placeholder="Please describe your issue in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-rose-300 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all placeholder:text-gray-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Upload Proof (Optional)
            </label>
            <button
              type="button"
              className="w-full p-8 border-4 border-dashed border-rose-300 rounded-2xl flex flex-col items-center gap-3 hover:bg-rose-50 hover:border-rose-400 transition-all"
            >
              <div className="p-4 bg-gradient-to-br from-rose-100 to-pink-100 rounded-2xl">
                <Upload className="w-8 h-8 text-rose-600" />
              </div>
              <div className="text-center">
                <p className="font-medium text-gray-800">Upload Screenshots</p>
                <p className="text-sm text-gray-600">PNG, JPG up to 10MB</p>
              </div>
            </button>
          </div>

          <Card className="p-4 bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200">
            <h4 className="font-bold text-gray-800 mb-2">Refund Policy</h4>
            <p className="text-sm text-gray-700">
              Refunds are processed within 5-7 business days. Once approved, credits will be returned to your account or original payment method.
            </p>
          </Card>

          <div className="space-y-3">
            <Button type="submit" fullWidth size="lg">
              Submit Request
            </Button>
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="w-full py-3 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
