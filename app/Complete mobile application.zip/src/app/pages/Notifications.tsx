import { useNavigate } from 'react-router';
import { ChevronLeft, Sparkles, ShoppingBag, Gift, AlertCircle, Check } from 'lucide-react';
import Card from '../components/Card';

const notifications = [
  {
    id: 1,
    type: 'ai',
    title: 'AI Generation Complete',
    message: 'Your photo is ready! Check out the stunning result.',
    time: '5 min ago',
    read: false,
  },
  {
    id: 2,
    type: 'reward',
    title: 'Referral Reward Earned',
    message: 'You earned 50 credits! Your friend Sarah joined using your code.',
    time: '2 hours ago',
    read: false,
  },
  {
    id: 3,
    type: 'order',
    title: 'Order Confirmed',
    message: 'Your purchase of "Sunset Beach" background is complete.',
    time: '1 day ago',
    read: true,
  },
  {
    id: 4,
    type: 'ai',
    title: 'AI Generation Complete',
    message: 'Your new creation is ready to download.',
    time: '2 days ago',
    read: true,
  },
  {
    id: 5,
    type: 'promo',
    title: 'Special Offer',
    message: '50% off on all credit packages this weekend only!',
    time: '3 days ago',
    read: true,
  },
];

export default function Notifications() {
  const navigate = useNavigate();

  const getIcon = (type: string) => {
    switch (type) {
      case 'ai':
        return <Sparkles className="w-5 h-5 text-purple-500" />;
      case 'reward':
        return <Gift className="w-5 h-5 text-green-500" />;
      case 'order':
        return <ShoppingBag className="w-5 h-5 text-blue-500" />;
      case 'promo':
        return <AlertCircle className="w-5 h-5 text-amber-500" />;
      default:
        return <Check className="w-5 h-5 text-gray-500" />;
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case 'ai':
        return 'bg-purple-100';
      case 'reward':
        return 'bg-green-100';
      case 'order':
        return 'bg-blue-100';
      case 'promo':
        return 'bg-amber-100';
      default:
        return 'bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Notifications</h1>
            <p className="text-sm text-gray-600">{notifications.filter(n => !n.read).length} unread</p>
          </div>
          <button className="text-sm text-rose-500 font-medium hover:text-rose-600">
            Mark all read
          </button>
        </div>
      </div>

      <div className="p-6 space-y-3">
        {notifications.map((notification) => (
          <Card
            key={notification.id}
            hoverable
            className={`p-4 ${!notification.read ? 'bg-gradient-to-br from-rose-50 to-pink-50 border-rose-200' : ''}`}
          >
            <div className="flex items-start gap-4">
              <div className={`p-2 rounded-xl ${getBgColor(notification.type)}`}>
                {getIcon(notification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-1">
                  <h4 className="font-bold text-gray-800">{notification.title}</h4>
                  {!notification.read && (
                    <div className="w-2 h-2 bg-rose-500 rounded-full flex-shrink-0 mt-2 ml-2" />
                  )}
                </div>
                <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                <p className="text-xs text-gray-500">{notification.time}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
