import { useNavigate } from 'react-router';
import { ChevronLeft, Gift, Copy, Share2, Users, Coins, Check } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const referralHistory = [
  { id: 1, name: 'Sarah Johnson', date: 'May 5, 2026', reward: 50, status: 'completed' },
  { id: 2, name: 'Mike Chen', date: 'May 3, 2026', reward: 50, status: 'completed' },
  { id: 3, name: 'Emma Davis', date: 'May 1, 2026', reward: 50, status: 'pending' },
];

export default function Referrals() {
  const navigate = useNavigate();
  const referralCode = 'JANE2026';

  const handleCopy = () => {
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Referrals & Rewards</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-3xl p-6 text-white shadow-xl">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-white/20 backdrop-blur-sm rounded-2xl mb-4">
              <Gift className="w-12 h-12" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Earn Free Credits</h2>
            <p className="text-purple-50">Get 50 credits for every friend who joins</p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
              <Users className="w-6 h-6 mx-auto mb-2" />
              <p className="text-3xl font-bold">{referralHistory.length}</p>
              <p className="text-purple-50 text-sm">Referrals</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
              <Coins className="w-6 h-6 mx-auto mb-2" />
              <p className="text-3xl font-bold">750</p>
              <p className="text-purple-50 text-sm">Credits Earned</p>
            </div>
          </div>

          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4">
            <p className="text-purple-50 text-sm mb-2 text-center">Your Referral Code</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-white/30 backdrop-blur-sm rounded-xl px-4 py-3 text-center">
                <p className="text-2xl font-bold tracking-wider">{referralCode}</p>
              </div>
              <button
                onClick={handleCopy}
                className="p-3 bg-white/30 backdrop-blur-sm rounded-xl hover:bg-white/40 transition-colors"
              >
                <Copy className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors">
            <Share2 className="w-6 h-6 text-blue-600" />
            <span className="text-xs font-medium text-gray-700">WhatsApp</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors">
            <Share2 className="w-6 h-6 text-pink-600" />
            <span className="text-xs font-medium text-gray-700">Instagram</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors">
            <Share2 className="w-6 h-6 text-gray-600" />
            <span className="text-xs font-medium text-gray-700">More</span>
          </button>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">Referral History</h3>
          <div className="space-y-3">
            {referralHistory.map((referral) => (
              <Card key={referral.id} className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-500 rounded-xl flex items-center justify-center text-white font-bold">
                    {referral.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-800">{referral.name}</h4>
                    <p className="text-sm text-gray-600">{referral.date}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-amber-600 font-bold mb-1">
                      <Coins className="w-4 h-4" />
                      <span>+{referral.reward}</span>
                    </div>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        referral.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-amber-100 text-amber-700'
                      }`}
                    >
                      {referral.status === 'completed' ? (
                        <>
                          <Check className="inline w-3 h-3 mr-1" />
                          Completed
                        </>
                      ) : (
                        'Pending'
                      )}
                    </span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <Card className="p-6 bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200">
          <h3 className="font-bold text-gray-800 mb-2">How It Works</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500">1.</span>
              <span>Share your unique referral code</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500">2.</span>
              <span>Friends sign up using your code</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500">3.</span>
              <span>You both get 50 free credits!</span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
