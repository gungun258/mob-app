import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Camera, User, Mail, Phone, MapPin, Instagram, Twitter, Globe, FileText } from 'lucide-react';
import Input from '../../components/Input';
import Button from '../../components/Button';
import Card from '../../components/Card';

export default function EditProfile() {
  const navigate = useNavigate();
  const [isSeller, setIsSeller] = useState(false);
  const [formData, setFormData] = useState({
    name: 'Jane Doe',
    email: 'jane.doe@email.com',
    phone: '+1 (555) 123-4567',
    address: '123 Main Street, New York, NY',
    storeDescription: '',
    instagram: '',
    twitter: '',
    website: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/account');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-purple-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Edit Profile</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Card className="p-4">
          <div className="flex gap-3">
            <button
              onClick={() => setIsSeller(false)}
              className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                !isSeller
                  ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              User Profile
            </button>
            <button
              onClick={() => setIsSeller(true)}
              className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                isSeller
                  ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Seller Profile
            </button>
          </div>
        </Card>

        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-24 h-24 bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 rounded-2xl flex items-center justify-center text-white text-3xl font-bold shadow-lg">
              JD
            </div>
            <button className="absolute -bottom-2 -right-2 p-3 bg-white rounded-xl shadow-lg border-2 border-gray-100 hover:bg-gray-50 transition-colors">
              <Camera className="w-5 h-5 text-gray-700" />
            </button>
          </div>
          <p className="mt-4 text-sm text-gray-600">Tap to change profile photo</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isSeller ? (
            <>
              <h3 className="font-bold text-gray-800">Basic Information</h3>

              <Input
                label="Full Name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                icon={<User className="w-5 h-5" />}
              />

              <Input
                label="Email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                icon={<Mail className="w-5 h-5" />}
              />

              <Input
                label="Phone Number"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                icon={<Phone className="w-5 h-5" />}
              />

              <Button
                onClick={() => navigate('/change-password')}
                variant="outline"
                fullWidth
                type="button"
              >
                Change Password
              </Button>
            </>
          ) : (
            <>
              <h3 className="font-bold text-gray-800">Store Information</h3>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Store Description
                </label>
                <textarea
                  placeholder="Tell customers about your store and products..."
                  value={formData.storeDescription}
                  onChange={(e) =>
                    setFormData({ ...formData, storeDescription: e.target.value })
                  }
                  rows={4}
                  className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-purple-300 focus:outline-none focus:ring-4 focus:ring-purple-100/50 transition-all placeholder:text-gray-400"
                />
              </div>

              <Input
                label="Store Address"
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                icon={<MapPin className="w-5 h-5" />}
              />

              <h3 className="font-bold text-gray-800 pt-4">Social Media Links</h3>

              <Input
                label="Instagram"
                type="text"
                placeholder="@yourusername"
                value={formData.instagram}
                onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                icon={<Instagram className="w-5 h-5" />}
              />

              <Input
                label="Twitter"
                type="text"
                placeholder="@yourusername"
                value={formData.twitter}
                onChange={(e) => setFormData({ ...formData, twitter: e.target.value })}
                icon={<Twitter className="w-5 h-5" />}
              />

              <Input
                label="Website"
                type="url"
                placeholder="https://yourwebsite.com"
                value={formData.website}
                onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                icon={<Globe className="w-5 h-5" />}
              />
            </>
          )}

          <div className="pt-6 space-y-3">
            <Button type="submit" fullWidth size="lg">
              Save Changes
            </Button>
            <button
              type="button"
              onClick={() => navigate('/account')}
              className="w-full py-3 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
