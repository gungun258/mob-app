import { useNavigate } from 'react-router';
import { ChevronLeft, Heart, Star, ShoppingBag } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const wishlistItems = [
  { id: 1, title: 'Sunset Beach', price: 15, rating: 4.8, saved: '2 days ago' },
  { id: 2, title: 'Mountain Vista', price: 20, rating: 4.9, saved: '5 days ago' },
  { id: 3, title: 'Urban Night', price: 12, rating: 4.7, saved: '1 week ago' },
  { id: 4, title: 'Forest Dream', price: 18, rating: 4.9, saved: '2 weeks ago' },
];

export default function Wishlist() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">My Wishlist</h1>
            <p className="text-sm text-gray-600">{wishlistItems.length} saved items</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        {wishlistItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="p-6 bg-gradient-to-br from-rose-100 to-pink-100 rounded-3xl mb-4">
              <Heart className="w-16 h-16 text-rose-500" />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">No Saved Items</h2>
            <p className="text-gray-600 mb-6">Start exploring and save your favorites</p>
            <Button onClick={() => navigate('/explore')}>
              Explore Backgrounds
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {wishlistItems.map((item) => (
              <Card
                key={item.id}
                onClick={() => navigate(`/product/${item.id}`)}
                hoverable
                className="overflow-hidden"
              >
                <div className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 relative">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                    className="absolute top-2 right-2 p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
                  >
                    <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                  </button>
                  <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-bold">{item.rating}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 mb-1">{item.title}</h3>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-rose-600 font-bold">${item.price}</span>
                    <span className="text-xs text-gray-500">{item.saved}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/product/${item.id}`);
                    }}
                    className="w-full flex items-center justify-center gap-2 py-2 bg-gradient-to-r from-rose-500 to-pink-500 text-white rounded-xl hover:shadow-lg transition-all text-sm font-medium"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Buy Now
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
