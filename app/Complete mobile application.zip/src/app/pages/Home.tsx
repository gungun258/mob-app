import { useNavigate } from 'react-router';
import { Sparkles, TrendingUp, Star, Bell, Coins, Heart, User, ChevronRight } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';

const trendingBackgrounds = [
  { id: 1, title: 'Sunset Beach', price: 15, rating: 4.8, sales: 234 },
  { id: 2, title: 'Mountain Vista', price: 20, rating: 4.9, sales: 189 },
  { id: 3, title: 'Urban Night', price: 12, rating: 4.7, sales: 156 },
  { id: 4, title: 'Forest Dream', price: 18, rating: 4.9, sales: 201 },
];

const topSellers = [
  { id: 1, name: "Sarah's Studio", listings: 156, rating: 4.9, following: true },
  { id: 2, name: 'Creative Minds', listings: 89, rating: 4.8, following: false },
  { id: 3, name: 'AI Art Pro', listings: 234, rating: 4.9, following: true },
  { id: 4, name: 'Photo Masters', listings: 127, rating: 4.7, following: false },
];

const followingListings = [
  { id: 1, seller: "Sarah's Studio", title: 'Ocean Dream', price: 18 },
  { id: 2, seller: 'AI Art Pro', title: 'City Lights', price: 22 },
  { id: 3, seller: "Sarah's Studio", title: 'Mountain Peak', price: 16 },
];

const publicGenerations = [
  { id: 1, user: 'Jane D.', likes: 234 },
  { id: 2, user: 'Mike C.', likes: 189 },
  { id: 3, user: 'Emma S.', likes: 312 },
  { id: 4, user: 'Alex K.', likes: 156 },
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blue-50/20 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              AI Photo Studio
            </h1>
            <p className="text-sm text-gray-600">Transform your moments</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/notifications')} className="relative p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <Bell className="w-6 h-6 text-gray-700" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full" />
            </button>
            <button onClick={() => navigate('/credits')} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-400 to-orange-400 rounded-xl shadow-sm">
              <Coins className="w-5 h-5 text-white" />
              <span className="text-white font-bold">250</span>
            </button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-xl">
          <h2 className="text-2xl font-bold mb-2">Create AI Magic</h2>
          <p className="text-blue-50 mb-6">Upload your photos and let AI do the rest</p>
          <div className="mt-4">
            <Button
              onClick={() => navigate('/generate')}
              variant="secondary"
              fullWidth
            >
              <Sparkles className="w-5 h-5" />
              Generate AI Image
            </Button>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              Trending Backgrounds
            </h2>
            <button
              onClick={() => navigate('/discover')}
              className="text-blue-600 font-medium hover:text-blue-700"
            >
              View All
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {trendingBackgrounds.map((bg) => (
              <Card
                key={bg.id}
                onClick={() => navigate(`/product/${bg.id}`)}
                hoverable
                className="overflow-hidden"
              >
                <div className="aspect-square bg-gradient-to-br from-cyan-200 via-blue-300 to-purple-300 relative">
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-bold">{bg.rating}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 mb-1">{bg.title}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-blue-600 font-bold">${bg.price}</span>
                    <span className="text-xs text-gray-500">{bg.sales} sales</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Top Sellers</h2>
            <button
              onClick={() => navigate('/sellers')}
              className="text-blue-600 font-medium hover:text-blue-700"
            >
              View All
            </button>
          </div>
          <div className="space-y-3">
            {topSellers.slice(0, 3).map((seller) => (
              <Card key={seller.id} hoverable className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-purple-500 rounded-xl flex items-center justify-center text-white text-xl font-bold">
                    {seller.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-800">{seller.name}</h3>
                    <div className="flex items-center gap-3 text-sm text-gray-600">
                      <span>{seller.listings} listings</span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        {seller.rating}
                      </span>
                    </div>
                  </div>
                  <button
                    className={`px-4 py-2 rounded-xl font-medium transition-all ${
                      seller.following
                        ? 'bg-gray-100 text-gray-700'
                        : 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                    }`}
                  >
                    {seller.following ? 'Following' : 'Follow'}
                  </button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">From Sellers You Follow</h2>
            <button
              onClick={() => navigate('/discover')}
              className="text-blue-600 font-medium hover:text-blue-700"
            >
              View All
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {followingListings.map((listing) => (
              <Card
                key={listing.id}
                onClick={() => navigate(`/product/${listing.id}`)}
                hoverable
                className="overflow-hidden"
              >
                <div className="aspect-square bg-gradient-to-br from-emerald-200 via-teal-300 to-cyan-300" />
                <div className="p-3">
                  <p className="text-xs text-gray-500 mb-1">{listing.seller}</p>
                  <h3 className="font-bold text-gray-800 mb-1">{listing.title}</h3>
                  <span className="text-blue-600 font-bold">${listing.price}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Public Generations</h2>
            <button className="text-blue-600 font-medium hover:text-blue-700">
              View All
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {publicGenerations.map((gen) => (
              <Card key={gen.id} hoverable className="overflow-hidden">
                <div className="aspect-square bg-gradient-to-br from-pink-200 via-rose-300 to-orange-300 relative">
                  <div className="absolute bottom-2 left-2 right-2 bg-white/90 backdrop-blur-sm rounded-xl p-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-600" />
                      <span className="text-xs font-medium text-gray-800">{gen.user}</span>
                    </div>
                    <div className="flex items-center gap-1 text-rose-600">
                      <Heart className="w-4 h-4 fill-rose-500" />
                      <span className="text-xs font-bold">{gen.likes}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200">
          <h3 className="font-bold text-gray-800 mb-2">Refer & Earn</h3>
          <p className="text-gray-600 text-sm mb-4">
            Get 50 free credits for every friend who joins
          </p>
          <Button onClick={() => navigate('/referrals')} variant="secondary" fullWidth>
            Start Referring
          </Button>
        </Card>
      </div>
    </div>
  );
}
