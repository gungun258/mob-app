import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, Image, Sparkles, ShoppingBag, Gift, ChevronRight } from 'lucide-react';
import Button from '../../components/Button';

const slides = [
  {
    icon: Upload,
    title: 'Upload Your Photo',
    description: 'Start by uploading your source photo that you want to transform',
    gradient: 'from-rose-400 to-pink-500',
  },
  {
    icon: Image,
    title: 'Choose Background',
    description: 'Select or upload a beautiful background from our marketplace',
    gradient: 'from-purple-400 to-indigo-500',
  },
  {
    icon: Sparkles,
    title: 'AI Magic',
    description: 'Our AI creates stunning, realistic photos combining both images',
    gradient: 'from-amber-400 to-orange-500',
  },
  {
    icon: ShoppingBag,
    title: 'Buy & Sell',
    description: 'Browse trending backgrounds or sell your own creations',
    gradient: 'from-emerald-400 to-teal-500',
  },
  {
    icon: Gift,
    title: 'Earn Rewards',
    description: 'Get credits through referrals and use them for AI generations',
    gradient: 'from-pink-400 to-rose-500',
  },
];

export default function Onboarding() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      navigate('/signup');
    }
  };

  const handleSkip = () => {
    navigate('/signup');
  };

  const slide = slides[currentSlide];
  const Icon = slide.icon;

  return (
    <div className="h-screen bg-gradient-to-br from-white via-rose-50 to-pink-50 flex flex-col">
      <div className="flex-1 flex items-center justify-center p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="text-center max-w-md"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.1, type: 'spring', stiffness: 200 }}
              className={`inline-block p-8 bg-gradient-to-br ${slide.gradient} rounded-3xl shadow-2xl mb-8`}
            >
              <Icon className="w-20 h-20 text-white" strokeWidth={1.5} />
            </motion.div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">{slide.title}</h2>
            <p className="text-lg text-gray-600">{slide.description}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="p-8 space-y-6">
        <div className="flex items-center justify-center gap-2">
          {slides.map((_, index) => (
            <div
              key={index}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === currentSlide
                  ? 'w-8 bg-gradient-to-r from-rose-400 to-pink-500'
                  : 'w-2 bg-gray-300'
              }`}
            />
          ))}
        </div>

        <div className="space-y-3">
          <Button onClick={handleNext} fullWidth size="lg">
            {currentSlide < slides.length - 1 ? (
              <>
                Next
                <ChevronRight className="w-5 h-5" />
              </>
            ) : (
              'Get Started'
            )}
          </Button>
          {currentSlide < slides.length - 1 && (
            <button
              onClick={handleSkip}
              className="w-full py-3 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Skip
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
