import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Mail } from 'lucide-react';
import Button from '../../components/Button';

export default function OTPVerification() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState(['', '', '', '', '', '']);

  const handleChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        nextInput?.focus();
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-rose-50 to-pink-50 flex flex-col">
      <div className="flex-1 p-8 flex flex-col justify-center max-w-md mx-auto w-full">
        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-gradient-to-br from-rose-100 to-pink-100 rounded-2xl mb-4">
            <Mail className="w-12 h-12 text-rose-500" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Verify Your Email</h1>
          <p className="text-gray-600">
            We've sent a verification code to
            <br />
            <span className="font-medium text-gray-800">your@email.com</span>
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex gap-3 justify-center">
            {otp.map((digit, index) => (
              <input
                key={index}
                id={`otp-${index}`}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                className="w-12 h-14 text-center text-xl font-bold border-2 border-gray-200 rounded-xl focus:border-rose-400 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all"
              />
            ))}
          </div>

          <Button type="submit" fullWidth size="lg">
            Verify & Continue
          </Button>

          <div className="text-center">
            <p className="text-gray-600">
              Didn't receive the code?{' '}
              <button type="button" className="text-rose-500 font-medium hover:text-rose-600">
                Resend
              </button>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
