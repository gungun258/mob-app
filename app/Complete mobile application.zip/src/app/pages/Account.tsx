import { useNavigate } from 'react-router';
import {
  User,
  Heart,
  Gift,
  CreditCard,
  Settings,
  Bell,
  ShoppingBag,
  Store,
  HelpCircle,
  Shield,
  FileText,
  LogOut,
  ChevronRight,
  Crown,
} from 'lucide-react';
import Card from '../components/Card';

const menuItems = [
  { icon: User, label: 'Edit Profile', path: '/edit-profile', color: 'text-rose-500' },
  { icon: Heart, label: 'Wishlist', path: '/wishlist', color: 'text-pink-500' },
  { icon: Gift, label: 'Referrals & Rewards', path: '/referrals', color: 'text-purple-500' },
  { icon: CreditCard, label: 'Credits & Plans', path: '/credits', color: 'text-amber-500' },
  { icon: ShoppingBag, label: 'Order History', path: '/orders', color: 'text-blue-500' },
  { icon: Store, label: 'Seller Dashboard', path: '/seller-dashboard', color: 'text-emerald-500' },
  { icon: Bell, label: 'Notifications', path: '/notifications', color: 'text-indigo-500' },
  { icon: Settings, label: 'Settings', path: '/settings', color: 'text-gray-600' },
];

const supportItems = [
  { icon: HelpCircle, label: 'FAQ', path: '/faq' },
  { icon: Shield, label: 'Privacy & Security', path: '/privacy' },
  { icon: FileText, label: 'Terms & Conditions', path: '/terms' },
  { icon: HelpCircle, label: 'Contact Support', path: '/support' },
];

export default function Account() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <h1 className="text-2xl font-bold text-gray-800">Account</h1>
      </div>

      <div className="p-6 space-y-6">
        <Card className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 bg-gradient-to-br from-rose-400 to-pink-500 rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-lg">
              JD
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-800">Jane Doe</h2>
              <p className="text-gray-600">jane.doe@email.com</p>
              <div className="flex items-center gap-2 mt-1">
                <Crown className="w-4 h-4 text-amber-500" />
                <span className="text-sm font-medium text-amber-600">Premium Member</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 p-4 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 rounded-2xl">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-800">42</p>
              <p className="text-xs text-gray-600">Generations</p>
            </div>
            <div className="text-center border-x border-purple-200">
              <p className="text-2xl font-bold text-gray-800">250</p>
              <p className="text-xs text-gray-600">Credits</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-800">24</p>
              <p className="text-xs text-gray-600">Following</p>
            </div>
          </div>
          <button
            onClick={() => navigate('/seller/1')}
            className="w-full mt-4 py-3 bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-700 rounded-xl hover:from-indigo-200 hover:to-purple-200 transition-all font-medium"
          >
            View Profile as Public
          </button>
        </Card>

        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Card
                key={item.path}
                onClick={() => navigate(item.path)}
                hoverable
                className="p-4"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 ${item.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="flex-1 font-medium text-gray-800">{item.label}</span>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </Card>
            );
          })}
        </div>

        <div className="pt-4">
          <h3 className="text-lg font-bold text-gray-800 mb-3">Support</h3>
          <div className="space-y-2">
            {supportItems.map((item) => {
              const Icon = item.icon;
              return (
                <Card
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  hoverable
                  className="p-4"
                >
                  <div className="flex items-center gap-4">
                    <Icon className="w-5 h-5 text-gray-600" />
                    <span className="flex-1 text-gray-700">{item.label}</span>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        <button
          onClick={() => navigate('/login')}
          className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-red-50 text-red-600 rounded-2xl hover:bg-red-100 transition-all font-medium"
        >
          <LogOut className="w-5 h-5" />
          Log Out
        </button>
      </div>
    </div>
  );
}
