import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Plus, TrendingUp, DollarSign, ShoppingBag, Eye, Search } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const activeListings = [
  { id: 1, title: 'Sunset Beach', price: 15, views: 234, sales: 12 },
  { id: 2, title: 'Mountain Vista', price: 20, views: 189, sales: 8 },
  { id: 3, title: 'Urban Night', price: 12, views: 156, sales: 15 },
];

export default function SellerDashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Seller Dashboard</h1>
            <p className="text-sm text-gray-600">Manage your listings</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <Card className="p-4 bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-emerald-500 rounded-xl">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm text-gray-600">Earnings</span>
            </div>
            <p className="text-3xl font-bold text-gray-800">$420</p>
            <p className="text-xs text-emerald-600 mt-1">+12% this month</p>
          </Card>

          <Card className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-500 rounded-xl">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm text-gray-600">Total Sales</span>
            </div>
            <p className="text-3xl font-bold text-gray-800">35</p>
            <p className="text-xs text-blue-600 mt-1">+5 this week</p>
          </Card>

          <Card className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-purple-500 rounded-xl">
                <Eye className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm text-gray-600">Views</span>
            </div>
            <p className="text-3xl font-bold text-gray-800">1.2K</p>
            <p className="text-xs text-purple-600 mt-1">+156 today</p>
          </Card>

          <Card className="p-4 bg-gradient-to-br from-rose-50 to-pink-50 border-rose-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-rose-500 rounded-xl">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm text-gray-600">Active Ads</span>
            </div>
            <p className="text-3xl font-bold text-gray-800">{activeListings.length}</p>
            <p className="text-xs text-rose-600 mt-1">All performing well</p>
          </Card>
        </div>

        <Button onClick={() => navigate('/post-ad')} fullWidth size="lg">
          <Plus className="w-5 h-5" />
          Post New Ad
        </Button>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">Active Listings</h3>
            <span className="text-sm text-gray-600">{activeListings.length} listings</span>
          </div>

          <div className="relative mb-4">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search your listings..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-emerald-300 focus:outline-none focus:ring-4 focus:ring-emerald-100/50 transition-all"
            />
          </div>
          <div className="space-y-3">
            {activeListings.map((listing) => (
              <Card key={listing.id} className="p-4" hoverable>
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 rounded-xl flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-gray-800 mb-1">{listing.title}</h4>
                    <p className="text-rose-600 font-bold mb-2">${listing.price}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {listing.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <ShoppingBag className="w-4 h-4" />
                        {listing.sales}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => navigate(`/edit-ad/${listing.id}`)}
                      className="px-4 py-2 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors text-sm font-medium"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
