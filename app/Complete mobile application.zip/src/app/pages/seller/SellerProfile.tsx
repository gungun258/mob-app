import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, Star, MapPin, Users, ShoppingBag, Check, Share2, Flag, Instagram, Twitter, Globe } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const sellerProducts = [
  { id: 1, title: 'Sunset Beach', price: 15, rating: 4.8 },
  { id: 2, title: 'Mountain Vista', price: 20, rating: 4.9 },
  { id: 3, title: 'Urban Night', price: 12, rating: 4.7 },
  { id: 4, title: 'Forest Dream', price: 18, rating: 4.9 },
  { id: 5, title: 'Ocean Waves', price: 14, rating: 4.6 },
  { id: 6, title: 'Desert Sunset', price: 22, rating: 4.9 },
];

export default function SellerProfile() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [isFollowing, setIsFollowing] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;
  const totalPages = Math.ceil(sellerProducts.length / itemsPerPage);
  const currentProducts = sellerProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-indigo-50/20 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800 flex-1">Seller Profile</h1>
          <button className="p-2 hover:bg-gray-100 rounded-xl">
            <Share2 className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Card className="p-6">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-indigo-400 via-purple-500 to-pink-500 rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-lg">
              SS
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-2xl font-bold text-gray-800">Sarah's Studio</h2>
                <div className="p-1 bg-blue-500 rounded-full">
                  <Check className="w-4 h-4 text-white" />
                </div>
              </div>
              <div className="flex items-center gap-1 text-amber-600 mb-2">
                <Star className="w-4 h-4 fill-amber-400" />
                <span className="font-bold">4.9</span>
                <span className="text-gray-600 text-sm">(234 reviews)</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 text-sm">
                <MapPin className="w-4 h-4" />
                <span>New York, USA</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3 mb-6">
            <Button
              onClick={() => setIsFollowing(!isFollowing)}
              fullWidth
              variant={isFollowing ? 'outline' : 'primary'}
            >
              {isFollowing ? 'Following' : 'Follow'}
            </Button>
            <button className="px-6 py-3 border-2 border-red-300 text-red-600 rounded-2xl hover:bg-red-50 transition-all font-medium flex items-center gap-2">
              <Flag className="w-5 h-5" />
              Report
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl mb-6">
            <div className="text-center">
              <ShoppingBag className="w-5 h-5 mx-auto mb-1 text-gray-600" />
              <p className="text-2xl font-bold text-gray-800">156</p>
              <p className="text-xs text-gray-600">Listings</p>
            </div>
            <div className="text-center border-x border-indigo-200">
              <Users className="w-5 h-5 mx-auto mb-1 text-gray-600" />
              <p className="text-2xl font-bold text-gray-800">2.4K</p>
              <p className="text-xs text-gray-600">Followers</p>
            </div>
            <div className="text-center">
              <Star className="w-5 h-5 mx-auto mb-1 text-gray-600" />
              <p className="text-2xl font-bold text-gray-800">1.2K</p>
              <p className="text-xs text-gray-600">Generations</p>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-3">About</h3>
            <p className="text-gray-700 leading-relaxed mb-4">
              Professional photographer specializing in nature and landscape backgrounds. All images are high-resolution and perfect for AI generation. Creating stunning visuals since 2020.
            </p>

            <h3 className="font-bold text-gray-800 mb-3">Connect</h3>
            <div className="flex gap-3">
              <a
                href="#"
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl hover:shadow-lg transition-all"
              >
                <Instagram className="w-5 h-5" />
                <span className="font-medium">Instagram</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-400 to-cyan-500 text-white rounded-xl hover:shadow-lg transition-all"
              >
                <Twitter className="w-5 h-5" />
                <span className="font-medium">Twitter</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl hover:shadow-lg transition-all"
              >
                <Globe className="w-5 h-5" />
                <span className="font-medium">Website</span>
              </a>
            </div>
          </div>
        </Card>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">
              Listings ({sellerProducts.length})
            </h3>
            {totalPages > 1 && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-700" />
                </button>
                <span className="text-sm text-gray-600">
                  {currentPage} / {totalPages}
                </span>
                <button
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                  className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-700 rotate-180" />
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            {currentProducts.map((product) => (
              <Card
                key={product.id}
                onClick={() => navigate(`/product/${product.id}`)}
                hoverable
                className="overflow-hidden"
              >
                <div className="aspect-square bg-gradient-to-br from-cyan-200 via-blue-300 to-purple-300 relative">
                  <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-bold">{product.rating}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 mb-1">{product.title}</h3>
                  <span className="text-indigo-600 font-bold">${product.price}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
