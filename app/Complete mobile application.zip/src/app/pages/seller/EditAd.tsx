import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, DollarSign, Type, Trash2 } from 'lucide-react';
import Input from '../../components/Input';
import Button from '../../components/Button';

const categories = ['Nature', 'Urban', 'Abstract', 'Minimalist', 'Vintage', 'Modern'];

export default function EditAd() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [formData, setFormData] = useState({
    title: 'Sunset Beach',
    description: 'Beautiful sunset beach background perfect for summer vibes',
    price: '15',
    category: 'Nature',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/seller-dashboard');
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this ad?')) {
      navigate('/seller-dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Edit Ad</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-3 gap-3">
          <div className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 rounded-2xl" />
          <div className="aspect-square bg-gradient-to-br from-blue-200 via-cyan-200 to-teal-200 rounded-2xl" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Product Title"
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            icon={<Type className="w-5 h-5" />}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-rose-300 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all"
            />
          </div>

          <Input
            label="Price (USD)"
            type="number"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            icon={<DollarSign className="w-5 h-5" />}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Category</label>
            <div className="grid grid-cols-2 gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setFormData({ ...formData, category })}
                  className={`px-4 py-3 rounded-2xl border-2 transition-all ${
                    formData.category === category
                      ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white border-rose-500'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-rose-300'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-6 space-y-3">
            <Button type="submit" fullWidth size="lg">
              Save Changes
            </Button>
            <button
              type="button"
              onClick={handleDelete}
              className="w-full flex items-center justify-center gap-2 py-3 bg-red-50 text-red-600 rounded-2xl hover:bg-red-100 transition-all font-medium"
            >
              <Trash2 className="w-5 h-5" />
              Delete Ad
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
