import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Upload, DollarSign, Tag, Type } from 'lucide-react';
import Input from '../../components/Input';
import Button from '../../components/Button';

const categories = ['Nature', 'Urban', 'Abstract', 'Minimalist', 'Vintage', 'Modern'];

export default function PostAd() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
  });
  const [images, setImages] = useState<number[]>([]);

  const handleAddImage = () => {
    setImages([...images, images.length + 1]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/seller-dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Post New Ad</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">Product Images</label>
          <div className="grid grid-cols-3 gap-3">
            {images.map((_, index) => (
              <div
                key={index}
                className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 rounded-2xl"
              />
            ))}
            {images.length < 6 && (
              <button
                onClick={handleAddImage}
                className="aspect-square border-4 border-dashed border-rose-300 rounded-2xl flex flex-col items-center justify-center gap-2 hover:bg-rose-50 hover:border-rose-400 transition-all"
              >
                <Upload className="w-8 h-8 text-rose-500" />
                <span className="text-xs text-gray-600 font-medium">Add Photo</span>
              </button>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Product Title"
            type="text"
            placeholder="e.g., Sunset Beach Background"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            icon={<Type className="w-5 h-5" />}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <textarea
              placeholder="Describe your background..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-rose-300 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all placeholder:text-gray-400"
            />
          </div>

          <Input
            label="Price (USD)"
            type="number"
            placeholder="0.00"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            icon={<DollarSign className="w-5 h-5" />}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Category</label>
            <div className="grid grid-cols-2 gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setFormData({ ...formData, category })}
                  className={`px-4 py-3 rounded-2xl border-2 transition-all ${
                    formData.category === category
                      ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white border-rose-500'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-rose-300'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-6 space-y-3">
            <Button type="submit" fullWidth size="lg">
              Publish Ad
            </Button>
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="w-full py-3 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
