import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, Heart, Share2, Star, ShoppingBag, Sparkles, User, ChevronRight } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';

const similarProducts = [
  { id: 2, title: 'Mountain Vista', price: 20 },
  { id: 3, title: 'Urban Night', price: 12 },
  { id: 4, title: 'Forest Dream', price: 18 },
];

export default function ProductDetails() {
  const navigate = useNavigate();
  const { id } = useParams();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800 flex-1">Product Details</h1>
          <button className="p-2 hover:bg-gray-100 rounded-xl">
            <Share2 className="w-6 h-6 text-gray-700" />
          </button>
          <button className="p-2 hover:bg-gray-100 rounded-xl">
            <Heart className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200" />

      <div className="p-6 space-y-6">
        <div>
          <div className="flex items-start justify-between mb-2">
            <h2 className="text-2xl font-bold text-gray-800">Sunset Beach</h2>
            <div className="flex items-center gap-1 bg-amber-50 px-3 py-1 rounded-full">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span className="font-bold text-gray-800">4.8</span>
              <span className="text-gray-600 text-sm">(234)</span>
            </div>
          </div>
          <p className="text-3xl font-bold text-rose-600 mb-4">$15</p>
          <p className="text-gray-600 leading-relaxed">
            Beautiful sunset beach background perfect for summer vibes and tropical photos. High-resolution image with stunning colors and natural lighting.
          </p>
        </div>

        <Card className="p-4" onClick={() => navigate('/seller/1')} hoverable>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-500 rounded-xl flex items-center justify-center text-white">
              <User className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800">Sarah's Studio</h3>
              <p className="text-sm text-gray-600">156 products • 4.9 rating</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </div>
        </Card>

        <div className="space-y-3">
          <div className="flex gap-3">
            <Button onClick={() => navigate('/generate')} variant="secondary" fullWidth size="lg">
              <Sparkles className="w-5 h-5" />
              Try with AI
            </Button>
            <Button fullWidth size="lg">
              <ShoppingBag className="w-5 h-5" />
              Buy Now
            </Button>
          </div>
          <Button onClick={() => navigate('/seller/1')} variant="outline" fullWidth>
            Contact Seller
          </Button>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">Similar Backgrounds</h3>
          <div className="grid grid-cols-3 gap-3">
            {similarProducts.map((product) => (
              <Card
                key={product.id}
                onClick={() => navigate(`/product/${product.id}`)}
                hoverable
                className="overflow-hidden"
              >
                <div className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200" />
                <div className="p-2">
                  <p className="text-xs font-medium text-gray-800 truncate">{product.title}</p>
                  <p className="text-xs font-bold text-rose-600">${product.price}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">Reviews</h3>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-gradient-to-br from-rose-400 to-pink-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    JD
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-gray-800 text-sm">Jane Doe</p>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star key={star} className="w-3 h-3 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">2 days ago</span>
                </div>
                <p className="text-gray-700 text-sm">
                  Amazing quality! The AI generation worked perfectly with this background.
                </p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
