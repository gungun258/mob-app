import { useNavigate } from 'react-router';
import { Search, Star, ChevronRight } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';

const followedSellers = [
  { id: 1, name: "Sarah's Studio", listings: 156, rating: 4.9 },
  { id: 2, name: 'AI Art Pro', listings: 234, rating: 4.9 },
  { id: 3, name: 'Creative Minds', listings: 89, rating: 4.8 },
  { id: 4, name: 'Photo Masters', listings: 127, rating: 4.7 },
];

const trendingSellers = [
  { id: 5, name: 'Pixel Perfect', listings: 178, rating: 4.8 },
  { id: 6, name: 'Visual Vibes', listings: 203, rating: 4.9 },
  { id: 7, name: 'Modern Backdrops', listings: 145, rating: 4.7 },
  { id: 8, name: 'Studio Elite', listings: 192, rating: 4.8 },
];

export default function Discover() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-purple-50/20 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Discover</h1>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search sellers, backgrounds..."
            className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-purple-300 focus:outline-none focus:ring-4 focus:ring-purple-100/50 transition-all"
          />
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Followed by You</h2>
            <button
              onClick={() => navigate('/sellers?filter=following')}
              className="text-purple-600 font-medium hover:text-purple-700"
            >
              View All
            </button>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {followedSellers.map((seller) => (
              <Card
                key={seller.id}
                onClick={() => navigate(`/seller/${seller.id}`)}
                hoverable
                className="min-w-[160px] flex-shrink-0 p-4"
              >
                <div className="w-full aspect-square bg-gradient-to-br from-purple-400 to-pink-500 rounded-xl mb-3 flex items-center justify-center text-white text-2xl font-bold">
                  {seller.name.charAt(0)}
                </div>
                <h3 className="font-bold text-gray-800 mb-1 text-sm truncate">{seller.name}</h3>
                <p className="text-xs text-gray-600 mb-2">{seller.listings} listings</p>
                <div className="flex items-center gap-1 justify-center text-amber-600">
                  <Star className="w-3 h-3 fill-amber-400" />
                  <span className="text-xs font-bold">{seller.rating}</span>
                </div>
              </Card>
            ))}
            <button
              onClick={() => navigate('/sellers?filter=following')}
              className="min-w-[160px] flex-shrink-0 h-full flex flex-col items-center justify-center p-4 border-2 border-dashed border-purple-300 rounded-2xl hover:bg-purple-50 transition-all"
            >
              <ChevronRight className="w-8 h-8 text-purple-500 mb-2" />
              <span className="text-sm font-medium text-purple-600">View All</span>
            </button>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Top Trending Sellers</h2>
            <button
              onClick={() => navigate('/sellers?filter=trending')}
              className="text-purple-600 font-medium hover:text-purple-700"
            >
              View All
            </button>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {trendingSellers.map((seller) => (
              <Card
                key={seller.id}
                onClick={() => navigate(`/seller/${seller.id}`)}
                hoverable
                className="min-w-[160px] flex-shrink-0 p-4"
              >
                <div className="w-full aspect-square bg-gradient-to-br from-blue-400 via-cyan-500 to-teal-500 rounded-xl mb-3 flex items-center justify-center text-white text-2xl font-bold">
                  {seller.name.charAt(0)}
                </div>
                <h3 className="font-bold text-gray-800 mb-1 text-sm truncate">{seller.name}</h3>
                <p className="text-xs text-gray-600 mb-2">{seller.listings} listings</p>
                <div className="flex items-center gap-1 justify-center text-amber-600">
                  <Star className="w-3 h-3 fill-amber-400" />
                  <span className="text-xs font-bold">{seller.rating}</span>
                </div>
              </Card>
            ))}
            <button
              onClick={() => navigate('/sellers?filter=trending')}
              className="min-w-[160px] flex-shrink-0 h-full flex flex-col items-center justify-center p-4 border-2 border-dashed border-purple-300 rounded-2xl hover:bg-purple-50 transition-all"
            >
              <ChevronRight className="w-8 h-8 text-purple-500 mb-2" />
              <span className="text-sm font-medium text-purple-600">View All</span>
            </button>
          </div>
        </div>

        <div className="pt-4">
          <Button
            onClick={() => navigate('/sellers')}
            fullWidth
            size="lg"
          >
            Explore All Sellers
          </Button>
        </div>

        <Card className="p-6 bg-gradient-to-br from-cyan-50 to-blue-50 border-2 border-cyan-200">
          <h3 className="font-bold text-gray-800 mb-2">Become a Seller</h3>
          <p className="text-gray-600 text-sm mb-4">
            Share your backgrounds and earn credits from each sale
          </p>
          <Button onClick={() => navigate('/seller-dashboard')} variant="secondary" fullWidth>
            Get Started
          </Button>
        </Card>
      </div>
    </div>
  );
}
