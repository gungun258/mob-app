import { useNavigate } from 'react-router';
import { ChevronLeft, Bell, Lock, Globe, Moon, HelpCircle, ChevronRight } from 'lucide-react';
import Card from '../components/Card';

const settingsSections = [
  {
    title: 'Preferences',
    items: [
      { icon: Bell, label: 'Notifications', path: '/notifications', value: 'On' },
      { icon: Globe, label: 'Language', path: '#', value: 'English' },
      { icon: Moon, label: 'Dark Mode', path: '#', value: 'Off' },
    ],
  },
  {
    title: 'Security',
    items: [
      { icon: Lock, label: 'Change Password', path: '/change-password' },
      { icon: Lock, label: 'Two-Factor Authentication', path: '#', value: 'Off' },
    ],
  },
  {
    title: 'Support',
    items: [
      { icon: HelpCircle, label: 'Help Center', path: '/faq' },
      { icon: HelpCircle, label: 'Contact Support', path: '/support' },
    ],
  },
];

export default function Settings() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Settings</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {settingsSections.map((section) => (
          <div key={section.title}>
            <h3 className="text-sm font-bold text-gray-500 uppercase mb-3 px-2">
              {section.title}
            </h3>
            <Card className="divide-y divide-gray-100">
              {section.items.map((item, index) => {
                const Icon = item.icon;
                return (
                  <button
                    key={index}
                    onClick={() => item.path && navigate(item.path)}
                    className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors"
                  >
                    <Icon className="w-5 h-5 text-gray-600" />
                    <span className="flex-1 text-left font-medium text-gray-800">
                      {item.label}
                    </span>
                    {item.value && (
                      <span className="text-sm text-gray-500">{item.value}</span>
                    )}
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </button>
                );
              })}
            </Card>
          </div>
        ))}

        <Card className="p-6 text-center">
          <p className="text-gray-600 text-sm mb-1">Version 1.0.0</p>
          <p className="text-gray-500 text-xs">© 2026 AI Photo Studio</p>
        </Card>
      </div>
    </div>
  );
}
