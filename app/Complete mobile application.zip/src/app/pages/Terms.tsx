import { useNavigate } from 'react-router';
import { ChevronLeft, FileText } from 'lucide-react';
import Card from '../components/Card';

export default function Terms() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Terms & Conditions</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-gray-700 to-gray-900 rounded-3xl p-6 text-white text-center shadow-xl">
          <div className="inline-block p-4 bg-white/20 backdrop-blur-sm rounded-2xl mb-4">
            <FileText className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Terms of Service</h2>
          <p className="text-gray-300">Please read these terms carefully before using our service</p>
        </div>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">1. Acceptance of Terms</h3>
          <p className="text-gray-700 leading-relaxed">
            By accessing and using AI Photo Studio, you accept and agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our service.
          </p>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">2. User Responsibilities</h3>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>You must be at least 13 years old to use this service</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>You are responsible for maintaining account security</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>You must not upload offensive or illegal content</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>You must respect intellectual property rights</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">3. AI-Generated Content</h3>
          <p className="text-gray-700 leading-relaxed mb-3">
            All AI-generated images created using our service are yours to use. However, we retain the right to use aggregated, anonymized data to improve our AI models.
          </p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>You own the rights to your AI-generated images</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Commercial use is permitted</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Attribution is not required but appreciated</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">4. Marketplace & Transactions</h3>
          <p className="text-gray-700 leading-relaxed">
            Our marketplace connects buyers and sellers. We facilitate transactions but are not responsible for the quality or accuracy of user-listed products. All sales are final unless otherwise stated in our refund policy.
          </p>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">5. Credits & Subscriptions</h3>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Credits are non-transferable and non-refundable once used</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Subscriptions auto-renew unless canceled</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>We reserve the right to modify pricing with notice</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">6. Limitation of Liability</h3>
          <p className="text-gray-700 leading-relaxed">
            AI Photo Studio provides services "as is" without warranties. We are not liable for any indirect, incidental, or consequential damages arising from your use of the service.
          </p>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">7. Changes to Terms</h3>
          <p className="text-gray-700 leading-relaxed">
            We reserve the right to modify these terms at any time. Continued use of the service after changes constitutes acceptance of the new terms.
          </p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-gray-50 to-gray-100">
          <p className="text-gray-600 text-sm text-center">
            Last updated: May 8, 2026
            <br />
            <span className="text-xs">Version 1.0</span>
          </p>
        </Card>
      </div>
    </div>
  );
}
