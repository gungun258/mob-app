import { useNavigate } from 'react-router';
import { ChevronLeft, Plus, Minus, Gift, ShoppingCart } from 'lucide-react';
import Card from '../../components/Card';

const history = [
  { id: 1, type: 'spent', amount: -10, reason: 'AI Generation', date: 'Today, 2:30 PM' },
  { id: 2, type: 'earned', amount: 50, reason: 'Referral Reward', date: 'Today, 10:15 AM' },
  { id: 3, type: 'purchased', amount: 300, reason: 'Pro Package', date: 'May 7, 2026' },
  { id: 4, type: 'spent', amount: -10, reason: 'AI Generation', date: 'May 7, 2026' },
  { id: 5, type: 'earned', amount: 10, reason: 'Daily Login Bonus', date: 'May 6, 2026' },
  { id: 6, type: 'spent', amount: -5, reason: 'HD Download', date: 'May 6, 2026' },
  { id: 7, type: 'earned', amount: 50, reason: 'Referral Reward', date: 'May 5, 2026' },
  { id: 8, type: 'spent', amount: -10, reason: 'AI Generation', date: 'May 5, 2026' },
];

export default function CreditHistory() {
  const navigate = useNavigate();

  const getIcon = (type: string) => {
    switch (type) {
      case 'earned':
        return <Gift className="w-5 h-5 text-green-500" />;
      case 'purchased':
        return <ShoppingCart className="w-5 h-5 text-blue-500" />;
      case 'spent':
        return <Minus className="w-5 h-5 text-red-500" />;
      default:
        return <Plus className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Credit History</h1>
            <p className="text-sm text-gray-600">All transactions</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-3">
        {history.map((item) => (
          <Card key={item.id} className="p-4">
            <div className="flex items-center gap-4">
              <div className={`p-2 rounded-xl ${
                item.type === 'earned' ? 'bg-green-100' :
                item.type === 'purchased' ? 'bg-blue-100' :
                'bg-red-100'
              }`}>
                {getIcon(item.type)}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-gray-800">{item.reason}</h4>
                <p className="text-sm text-gray-600">{item.date}</p>
              </div>
              <div className="text-right">
                <p className={`text-xl font-bold ${
                  item.amount > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {item.amount > 0 ? '+' : ''}{item.amount}
                </p>
                <p className="text-xs text-gray-500">credits</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
