import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Coins, Check, Crown } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const packages = [
  {
    id: 1,
    name: 'Starter',
    credits: 100,
    price: 9.99,
    popular: false,
    features: ['100 AI generations', 'Standard support', 'Valid for 30 days'],
  },
  {
    id: 2,
    name: 'Pro',
    credits: 300,
    price: 24.99,
    popular: true,
    features: ['300 AI generations', 'Priority support', 'Valid for 60 days', 'Bonus features'],
  },
  {
    id: 3,
    name: 'Premium',
    credits: 1000,
    price: 74.99,
    popular: false,
    features: ['1000 AI generations', '24/7 VIP support', 'Valid for 90 days', 'All premium features'],
  },
];

const subscriptions = [
  {
    id: 1,
    name: 'Monthly',
    credits: 150,
    price: 14.99,
    period: 'month',
    features: ['150 credits/month', 'Cancel anytime', 'Priority support'],
  },
  {
    id: 2,
    name: 'Annual',
    credits: 2000,
    price: 149.99,
    period: 'year',
    savings: 'Save $30',
    features: ['2000 credits/year', 'Best value', 'VIP support', 'Exclusive perks'],
  },
];

export default function BuyPackages() {
  const navigate = useNavigate();
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null);
  const [tab, setTab] = useState<'credits' | 'subscription'>('credits');

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Buy Credits</h1>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setTab('credits')}
            className={`flex-1 py-3 rounded-2xl font-medium transition-all ${
              tab === 'credits'
                ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-lg'
                : 'bg-white border-2 border-gray-200 text-gray-700'
            }`}
          >
            Credit Packs
          </button>
          <button
            onClick={() => setTab('subscription')}
            className={`flex-1 py-3 rounded-2xl font-medium transition-all ${
              tab === 'subscription'
                ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-lg'
                : 'bg-white border-2 border-gray-200 text-gray-700'
            }`}
          >
            Subscriptions
          </button>
        </div>
      </div>

      <div className="p-6 space-y-4">
        {tab === 'credits' ? (
          <>
            {packages.map((pkg) => (
              <Card
                key={pkg.id}
                onClick={() => setSelectedPackage(pkg.id)}
                hoverable
                className={`p-6 ${
                  selectedPackage === pkg.id
                    ? 'ring-4 ring-rose-400 bg-gradient-to-br from-rose-50 to-pink-50'
                    : ''
                } ${pkg.popular ? 'border-2 border-purple-400' : ''}`}
              >
                {pkg.popular && (
                  <div className="mb-3">
                    <span className="inline-block px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold rounded-full">
                      MOST POPULAR
                    </span>
                  </div>
                )}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-1">{pkg.name}</h3>
                    <div className="flex items-center gap-2 text-amber-600 mb-2">
                      <Coins className="w-5 h-5" />
                      <span className="text-xl font-bold">{pkg.credits} Credits</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-gray-800">${pkg.price}</p>
                    <p className="text-xs text-gray-600">one-time</p>
                  </div>
                </div>
                <ul className="space-y-2 mb-4">
                  {pkg.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-gray-700">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                {selectedPackage === pkg.id && (
                  <div className="pt-4">
                    <Button fullWidth>Purchase</Button>
                  </div>
                )}
              </Card>
            ))}
          </>
        ) : (
          <>
            {subscriptions.map((sub) => (
              <Card
                key={sub.id}
                onClick={() => setSelectedPackage(sub.id)}
                hoverable
                className={`p-6 ${
                  selectedPackage === sub.id
                    ? 'ring-4 ring-rose-400 bg-gradient-to-br from-rose-50 to-pink-50'
                    : ''
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-2xl font-bold text-gray-800">{sub.name}</h3>
                      {sub.savings && (
                        <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">
                          {sub.savings}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-purple-600 mb-2">
                      <Crown className="w-5 h-5" />
                      <span className="text-xl font-bold">{sub.credits} Credits</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-gray-800">${sub.price}</p>
                    <p className="text-xs text-gray-600">per {sub.period}</p>
                  </div>
                </div>
                <ul className="space-y-2 mb-4">
                  {sub.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-gray-700">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                {selectedPackage === sub.id && (
                  <div className="pt-4">
                    <Button fullWidth>Subscribe</Button>
                  </div>
                )}
              </Card>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
