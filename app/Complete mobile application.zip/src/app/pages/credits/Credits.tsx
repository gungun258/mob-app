import { useNavigate } from 'react-router';
import { ChevronLeft, Coins, ShoppingCart, Gift, History } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

export default function Credits() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Credits & Plans</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-amber-400 to-orange-500 rounded-3xl p-8 text-white text-center shadow-xl">
          <div className="inline-block p-4 bg-white/20 backdrop-blur-sm rounded-2xl mb-4">
            <Coins className="w-12 h-12" />
          </div>
          <p className="text-amber-50 text-sm mb-2">Available Credits</p>
          <h2 className="text-5xl font-bold mb-4">250</h2>
          <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3">
            <p className="text-sm">Each AI generation uses 10 credits</p>
            <p className="text-amber-50 text-xs mt-1">25 generations remaining</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Card
            onClick={() => navigate('/buy-packages')}
            hoverable
            className="p-4 text-center"
          >
            <ShoppingCart className="w-8 h-8 mx-auto mb-2 text-rose-500" />
            <p className="text-sm font-medium text-gray-800">Buy Credits</p>
          </Card>

          <Card
            onClick={() => navigate('/referrals')}
            hoverable
            className="p-4 text-center"
          >
            <Gift className="w-8 h-8 mx-auto mb-2 text-purple-500" />
            <p className="text-sm font-medium text-gray-800">Free Credits</p>
          </Card>

          <Card
            onClick={() => navigate('/credit-history')}
            hoverable
            className="p-4 text-center"
          >
            <History className="w-8 h-8 mx-auto mb-2 text-blue-500" />
            <p className="text-sm font-medium text-gray-800">History</p>
          </Card>
        </div>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">How Credits Work</h3>
          <Card className="p-6 space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-rose-100 rounded-xl">
                <span className="text-rose-600 font-bold">10</span>
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-800">AI Generation</p>
                <p className="text-sm text-gray-600">Create one AI-powered photo</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-purple-100 rounded-xl">
                <span className="text-purple-600 font-bold">5</span>
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-800">HD Download</p>
                <p className="text-sm text-gray-600">Download in high resolution</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-100 rounded-xl">
                <span className="text-blue-600 font-bold">0</span>
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-800">Browse & Save</p>
                <p className="text-sm text-gray-600">Always free to explore</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
          <h3 className="font-bold text-gray-800 mb-3">Earn Free Credits</h3>
          <ul className="space-y-2 text-sm text-gray-700 mb-4">
            <li className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-500" />
              <span>50 credits for each referral</span>
            </li>
            <li className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-500" />
              <span>10 credits daily login bonus</span>
            </li>
            <li className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-500" />
              <span>Bonus credits on special occasions</span>
            </li>
          </ul>
          <Button onClick={() => navigate('/referrals')} variant="secondary" fullWidth>
            Start Earning
          </Button>
        </Card>
      </div>
    </div>
  );
}
