import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, Download, Share2, Heart, RefreshCw, ShoppingBag, X, MoreVertical, MessageCircle } from 'lucide-react';
import Button from '../../components/Button';
import Card from '../../components/Card';

export default function ResultScreen() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [showComparison, setShowComparison] = useState(false);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [showMenu, setShowMenu] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blue-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/my-generations')} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800 flex-1">Your AI Creation</h1>
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 hover:bg-gray-100 rounded-xl relative"
          >
            <MoreVertical className="w-6 h-6 text-gray-700" />
            {showMenu && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden z-20">
                <button
                  onClick={() => navigate(`/refund/${id}`)}
                  className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors text-gray-700"
                >
                  Request Refund
                </button>
                <button
                  onClick={() => navigate('/support')}
                  className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors text-gray-700 border-t border-gray-100"
                >
                  Contact Support
                </button>
                <button className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors text-red-600 border-t border-gray-100">
                  Report Issue
                </button>
              </div>
            )}
          </button>
          <button className="p-2 hover:bg-gray-100 rounded-xl">
            <Share2 className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Card className="overflow-hidden bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
          <div className="p-4 text-center bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white">
            <p className="font-bold">AI Generation Complete! 🎉</p>
          </div>

          {!showComparison ? (
            <div className="aspect-square bg-gradient-to-br from-cyan-200 via-blue-300 to-purple-300" />
          ) : (
            <div className="aspect-square relative overflow-hidden bg-gray-100">
              <div className="absolute inset-0 flex">
                <div
                  className="bg-gradient-to-br from-blue-200 to-cyan-200"
                  style={{ width: `${sliderPosition}%` }}
                >
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-800">
                    Before
                  </div>
                </div>
                <div className="flex-1 bg-gradient-to-br from-cyan-200 via-blue-300 to-purple-300">
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-800">
                    After
                  </div>
                </div>
              </div>
              <div
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize shadow-lg"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center">
                  <div className="flex gap-0.5">
                    <div className="w-0.5 h-4 bg-gray-400" />
                    <div className="w-0.5 h-4 bg-gray-400" />
                  </div>
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={sliderPosition}
                onChange={(e) => setSliderPosition(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
              />
            </div>
          )}

          <div className="p-4">
            <button
              onClick={() => setShowComparison(!showComparison)}
              className="w-full py-3 bg-white rounded-xl font-medium text-gray-800 hover:bg-gray-50 transition-colors"
            >
              {showComparison ? (
                <>
                  <X className="inline w-4 h-4 mr-2" />
                  Hide Comparison
                </>
              ) : (
                'View Before & After'
              )}
            </button>
          </div>
        </Card>

        <div className="grid grid-cols-4 gap-3">
          <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors">
            <Heart className="w-6 h-6 text-gray-600" />
            <span className="text-xs font-medium text-gray-700">Save</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors">
            <Download className="w-6 h-6 text-gray-600" />
            <span className="text-xs font-medium text-gray-700">Download</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors">
            <Share2 className="w-6 h-6 text-gray-600" />
            <span className="text-xs font-medium text-gray-700">Share</span>
          </button>
          <button
            onClick={() => navigate('/select-style')}
            className="flex flex-col items-center gap-2 p-4 bg-white rounded-2xl border-2 border-gray-200 hover:bg-gray-50 transition-colors"
          >
            <RefreshCw className="w-6 h-6 text-gray-600" />
            <span className="text-xs font-medium text-gray-700">Retry</span>
          </button>
        </div>

        <div className="flex gap-3">
          <Button onClick={() => navigate('/product/1')} variant="outline" fullWidth>
            <ShoppingBag className="w-5 h-5" />
            Buy Background
          </Button>
          <Button onClick={() => navigate('/generate')} fullWidth>
            Create Another
          </Button>
        </div>

        <Card className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-purple-400 to-pink-500 rounded-xl">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800 mb-1">Used a seller's background?</h3>
              <p className="text-sm text-gray-700">Contact them to purchase the original</p>
            </div>
          </div>
          <Button
            onClick={() => navigate('/seller/1')}
            variant="secondary"
            fullWidth
            className="mt-4"
          >
            Visit Seller Profile
          </Button>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200">
          <div className="flex items-start gap-4">
            <div className="text-3xl">💡</div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800 mb-2">Love this result?</h3>
              <p className="text-sm text-gray-700 mb-4">
                Save it to your favorites and share with friends to earn bonus credits!
              </p>
              <Button onClick={() => navigate('/referrals')} size="sm" variant="secondary">
                Earn Credits
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
