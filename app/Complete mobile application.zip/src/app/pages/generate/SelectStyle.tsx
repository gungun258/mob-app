import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Check } from 'lucide-react';
import Button from '../../components/Button';
import Card from '../../components/Card';

const styles = [
  {
    id: 1,
    name: 'Natural',
    description: 'Realistic, photographic blend',
    gradient: 'from-emerald-200 via-teal-300 to-cyan-300',
  },
  {
    id: 2,
    name: 'Artistic',
    description: 'Painterly, creative effect',
    gradient: 'from-purple-200 via-pink-300 to-rose-300',
  },
  {
    id: 3,
    name: 'Cinematic',
    description: 'Movie-like, dramatic look',
    gradient: 'from-blue-200 via-indigo-300 to-purple-300',
  },
  {
    id: 4,
    name: 'Vintage',
    description: 'Retro, nostalgic feel',
    gradient: 'from-amber-200 via-orange-300 to-red-300',
  },
  {
    id: 5,
    name: 'Modern',
    description: 'Clean, contemporary style',
    gradient: 'from-gray-200 via-slate-300 to-zinc-300',
  },
  {
    id: 6,
    name: 'Vibrant',
    description: 'Bold, saturated colors',
    gradient: 'from-fuchsia-200 via-violet-300 to-purple-300',
  },
];

export default function SelectStyle() {
  const navigate = useNavigate();
  const [selectedStyle, setSelectedStyle] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-purple-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Select Style</h1>
            <p className="text-sm text-gray-600">Choose how to apply the background</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200">
          <h3 className="font-bold text-gray-800 mb-2">Preview</h3>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <p className="text-xs text-gray-600 mb-2">Your Photo</p>
              <div className="aspect-square bg-gradient-to-br from-blue-200 to-cyan-200 rounded-xl" />
            </div>
            <div>
              <p className="text-xs text-gray-600 mb-2">Background</p>
              <div className="aspect-square bg-gradient-to-br from-purple-200 to-pink-200 rounded-xl" />
            </div>
          </div>
          <p className="text-sm text-gray-600">
            Select a style below to see how your final image will look
          </p>
        </Card>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">Available Styles</h3>
          <div className="grid grid-cols-2 gap-4">
            {styles.map((style) => (
              <Card
                key={style.id}
                onClick={() => setSelectedStyle(style.id)}
                hoverable
                className={`overflow-hidden ${
                  selectedStyle === style.id ? 'ring-4 ring-purple-400' : ''
                }`}
              >
                <div className={`aspect-square bg-gradient-to-br ${style.gradient} relative`}>
                  {selectedStyle === style.id && (
                    <div className="absolute inset-0 bg-purple-500/20 flex items-center justify-center">
                      <div className="bg-purple-500 text-white p-3 rounded-full">
                        <Check className="w-6 h-6" />
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 mb-1">{style.name}</h3>
                  <p className="text-xs text-gray-600">{style.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {selectedStyle && (
          <div className="fixed bottom-20 left-0 right-0 p-6 bg-gradient-to-t from-white via-white to-transparent">
            <Button
              onClick={() => navigate('/ai-processing')}
              fullWidth
              size="lg"
            >
              Generate with {styles.find(s => s.id === selectedStyle)?.name} Style
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
