import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Sparkles, Wand2, Zap } from 'lucide-react';

export default function AIProcessing() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/result/1');
    }, 4000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-rose-500 flex flex-col items-center justify-center p-8">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="text-center"
      >
        <motion.div
          animate={{
            rotate: [0, 360],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="inline-block p-8 bg-white/20 backdrop-blur-sm rounded-3xl mb-8"
        >
          <Sparkles className="w-20 h-20 text-white" />
        </motion.div>

        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-3xl font-bold text-white mb-4"
        >
          AI is Creating Magic
        </motion.h1>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-white/90 text-lg mb-8"
        >
          Generating your stunning photo...
        </motion.p>

        <div className="space-y-4 max-w-sm mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="flex items-center gap-4 bg-white/20 backdrop-blur-sm rounded-2xl p-4"
          >
            <div className="p-2 bg-white/30 rounded-xl">
              <Wand2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-white font-medium">Analyzing photos...</span>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.2, duration: 0.5 }}
            className="flex items-center gap-4 bg-white/20 backdrop-blur-sm rounded-2xl p-4"
          >
            <div className="p-2 bg-white/30 rounded-xl">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-white font-medium">Applying AI magic...</span>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.6, duration: 0.5 }}
            className="flex items-center gap-4 bg-white/20 backdrop-blur-sm rounded-2xl p-4"
          >
            <div className="p-2 bg-white/30 rounded-xl">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-white font-medium">Finalizing details...</span>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 0.5 }}
          className="mt-8"
        >
          <div className="w-64 h-2 bg-white/20 rounded-full overflow-hidden mx-auto">
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ duration: 3, ease: 'easeInOut' }}
              className="h-full bg-white rounded-full"
            />
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
