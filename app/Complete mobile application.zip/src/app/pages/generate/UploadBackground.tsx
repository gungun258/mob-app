import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Upload, Search, Star, Check } from 'lucide-react';
import Button from '../../components/Button';
import Card from '../../components/Card';

const trendingBackgrounds = [
  { id: 1, title: 'Sunset Beach', price: 15, rating: 4.8 },
  { id: 2, title: 'Mountain Vista', price: 20, rating: 4.9 },
  { id: 3, title: 'Urban Night', price: 12, rating: 4.7 },
  { id: 4, title: 'Forest Dream', price: 18, rating: 4.9 },
  { id: 5, title: 'Ocean Waves', price: 14, rating: 4.6 },
  { id: 6, title: 'Desert Sunset', price: 22, rating: 4.9 },
];

export default function UploadBackground() {
  const navigate = useNavigate();
  const [selectedBackground, setSelectedBackground] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Choose Background</h1>
            <p className="text-sm text-gray-600">Step 2 of 2</p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search backgrounds..."
            className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-rose-300 focus:outline-none focus:ring-4 focus:ring-rose-100/50 transition-all"
          />
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Card
          onClick={() => {}}
          hoverable
          className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200"
        >
          <div className="flex items-center gap-4">
            <div className="p-4 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl">
              <Upload className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800 mb-1">Upload Custom Background</h3>
              <p className="text-sm text-gray-600">Use your own image</p>
            </div>
          </div>
        </Card>

        <div>
          <h3 className="font-bold text-gray-800 mb-4">Trending Backgrounds</h3>
          <div className="grid grid-cols-2 gap-4">
            {trendingBackgrounds.map((bg) => (
              <Card
                key={bg.id}
                onClick={() => setSelectedBackground(bg.id)}
                hoverable
                className={`overflow-hidden ${
                  selectedBackground === bg.id ? 'ring-4 ring-rose-400' : ''
                }`}
              >
                <div className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 relative">
                  {selectedBackground === bg.id && (
                    <div className="absolute inset-0 bg-rose-500/20 flex items-center justify-center">
                      <div className="bg-rose-500 text-white p-3 rounded-full">
                        <Check className="w-6 h-6" />
                      </div>
                    </div>
                  )}
                  <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-bold">{bg.rating}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 mb-1">{bg.title}</h3>
                  <span className="text-rose-600 font-bold">${bg.price}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {selectedBackground && (
          <div className="fixed bottom-20 left-0 right-0 p-6 bg-gradient-to-t from-white via-white to-transparent">
            <Button
              onClick={() => navigate('/select-style')}
              fullWidth
              size="lg"
            >
              Next: Select Style
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
