import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Upload, Camera, Image as ImageIcon, Check } from 'lucide-react';
import Button from '../../components/Button';
import Card from '../../components/Card';

export default function UploadUserPhoto() {
  const navigate = useNavigate();
  const [uploadedImage, setUploadedImage] = useState(false);

  const handleFileUpload = () => {
    setUploadedImage(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Upload Your Photo</h1>
            <p className="text-sm text-gray-600">Step 1 of 2</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-rose-50 to-pink-50 rounded-2xl p-6 border-2 border-rose-200">
          <h3 className="font-bold text-gray-800 mb-3">Photo Guidelines</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-rose-500 mt-0.5 flex-shrink-0" />
              <span>Use clear, well-lit photos</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-rose-500 mt-0.5 flex-shrink-0" />
              <span>Face the camera directly</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-rose-500 mt-0.5 flex-shrink-0" />
              <span>Avoid busy backgrounds</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-rose-500 mt-0.5 flex-shrink-0" />
              <span>High resolution recommended</span>
            </li>
          </ul>
        </div>

        {!uploadedImage ? (
          <div className="space-y-4">
            <button
              onClick={handleFileUpload}
              className="w-full aspect-square bg-white border-4 border-dashed border-rose-300 rounded-3xl flex flex-col items-center justify-center gap-4 hover:bg-rose-50 hover:border-rose-400 transition-all"
            >
              <div className="p-6 bg-gradient-to-br from-rose-100 to-pink-100 rounded-2xl">
                <Upload className="w-16 h-16 text-rose-600" />
              </div>
              <div className="text-center">
                <p className="text-lg font-bold text-gray-800">Upload Your Photo</p>
                <p className="text-sm text-gray-600">Tap to select from gallery</p>
              </div>
            </button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-white text-gray-500">Or</span>
              </div>
            </div>

            <Card hoverable className="p-6" onClick={handleFileUpload}>
              <div className="flex items-center gap-4">
                <div className="p-4 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-2xl">
                  <Camera className="w-8 h-8 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800 mb-1">Take a Photo</h3>
                  <p className="text-sm text-gray-600">Use your camera</p>
                </div>
              </div>
            </Card>
          </div>
        ) : (
          <div className="space-y-4">
            <Card className="overflow-hidden">
              <div className="aspect-square bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 relative">
                <div className="absolute top-4 right-4 bg-green-500 text-white p-2 rounded-full">
                  <Check className="w-6 h-6" />
                </div>
              </div>
              <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50">
                <p className="text-center font-medium text-green-800">Photo uploaded successfully!</p>
              </div>
            </Card>

            <div className="flex gap-3">
              <Button onClick={handleFileUpload} variant="outline" fullWidth>
                <ImageIcon className="w-5 h-5" />
                Change Photo
              </Button>
              <Button onClick={() => navigate('/upload-background')} fullWidth>
                Next Step
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
