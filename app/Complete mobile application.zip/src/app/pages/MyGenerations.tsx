import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Search, Grid3x3, LayoutGrid, Heart, Download, Trash2, Globe } from 'lucide-react';
import Card from '../components/Card';

const myPhotos = [
  { id: 1, title: 'My Photo 1', type: 'raw', date: '2 hours ago' },
  { id: 2, title: 'My Photo 2', type: 'raw', date: '5 hours ago' },
];

const generations = [
  { id: 3, title: 'Beach Sunset Look', date: '2 hours ago', liked: true, public: true },
  { id: 4, title: 'Mountain Adventure', date: '5 hours ago', liked: false, public: false },
  { id: 5, title: 'City Night Vibes', date: '1 day ago', liked: true, public: true },
  { id: 6, title: 'Forest Escape', date: '2 days ago', liked: false, public: false },
  { id: 7, title: 'Desert Dreams', date: '3 days ago', liked: true, public: false },
  { id: 8, title: 'Ocean Paradise', date: '4 days ago', liked: false, public: true },
];

const filters = ['All', 'Raw Photos', 'Generations', 'Favorites', 'Public'];

export default function MyGenerations() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'grid' | 'large'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<string>('All');
  const [selectedItems, setSelectedItems] = useState<number[]>([]);

  const allItems = [...myPhotos, ...generations];

  const filteredItems = allItems.filter((item) => {
    if (filter === 'All') return true;
    if (filter === 'Raw Photos') return item.type === 'raw';
    if (filter === 'Generations') return item.type !== 'raw';
    if (filter === 'Favorites') return 'liked' in item && item.liked;
    if (filter === 'Public') return 'public' in item && item.public;
    return true;
  });

  const toggleSelect = (id: number) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const deleteSelected = () => {
    if (confirm(`Delete ${selectedItems.length} item(s)?`)) {
      setSelectedItems([]);
    }
  };

  const makePublic = (id: number) => {
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-pink-50/20 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">My Gallery</h1>
            <p className="text-sm text-gray-600">{filteredItems.length} items</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-xl transition-colors ${
                viewMode === 'grid'
                  ? 'bg-pink-100 text-pink-600'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              <Grid3x3 className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('large')}
              className={`p-2 rounded-xl transition-colors ${
                viewMode === 'large'
                  ? 'bg-pink-100 text-pink-600'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              <LayoutGrid className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search gallery..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-pink-300 focus:outline-none focus:ring-4 focus:ring-pink-100/50 transition-all"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                filter === f
                  ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg'
                  : 'bg-white border-2 border-gray-200 text-gray-700'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {selectedItems.length > 0 && (
          <div className="mt-4 flex items-center gap-3">
            <span className="text-sm font-medium text-gray-700">
              {selectedItems.length} selected
            </span>
            <button
              onClick={deleteSelected}
              className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-all font-medium"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </button>
            <button
              onClick={() => setSelectedItems([])}
              className="text-sm text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      <div className="p-6">
        <div className={`grid ${viewMode === 'grid' ? 'grid-cols-2' : 'grid-cols-1'} gap-4`}>
          {filteredItems.map((item) => {
            const isRaw = item.type === 'raw';
            const isSelected = selectedItems.includes(item.id);

            return (
              <Card
                key={item.id}
                onClick={() => !isRaw && navigate(`/result/${item.id}`)}
                className={`overflow-hidden ${isSelected ? 'ring-4 ring-pink-400' : ''}`}
              >
                <div
                  className={`${
                    viewMode === 'grid' ? 'aspect-square' : 'aspect-[4/3]'
                  } bg-gradient-to-br ${
                    isRaw
                      ? 'from-gray-200 via-slate-300 to-zinc-300'
                      : 'from-cyan-200 via-blue-300 to-purple-300'
                  } relative`}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    toggleSelect(item.id);
                  }}
                >
                  {isRaw && (
                    <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg">
                      <span className="text-xs font-bold text-gray-700">RAW</span>
                    </div>
                  )}

                  {!isRaw && (
                    <>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSelect(item.id);
                        }}
                        className={`absolute top-2 left-2 p-2 rounded-full transition-all ${
                          isSelected
                            ? 'bg-pink-500 text-white'
                            : 'bg-white/90 backdrop-blur-sm text-gray-600 hover:bg-white'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="w-4 h-4 pointer-events-none"
                        />
                      </button>

                      {'liked' in item && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                          }}
                          className="absolute top-2 right-2 p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors"
                        >
                          <Heart
                            className={`w-4 h-4 ${
                              item.liked
                                ? 'fill-rose-500 text-rose-500'
                                : 'text-gray-600'
                            }`}
                          />
                        </button>
                      )}

                      <div className="absolute bottom-2 left-2 right-2 flex gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                          }}
                          className="flex-1 p-2 bg-white/90 backdrop-blur-sm rounded-xl hover:bg-white transition-colors flex items-center justify-center gap-1"
                        >
                          <Download className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            makePublic(item.id);
                          }}
                          className={`flex-1 p-2 rounded-xl transition-colors flex items-center justify-center gap-1 ${
                            'public' in item && item.public
                              ? 'bg-emerald-500 text-white'
                              : 'bg-white/90 backdrop-blur-sm text-gray-600 hover:bg-white'
                          }`}
                        >
                          <Globe className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 mb-1">{item.title}</h3>
                  <p className="text-xs text-gray-500">{item.date}</p>
                  {!isRaw && 'public' in item && item.public && (
                    <span className="inline-block mt-2 px-2 py-1 bg-emerald-100 text-emerald-700 text-xs rounded-full">
                      Public
                    </span>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
