import { useNavigate } from 'react-router';
import { ChevronLeft, Shield } from 'lucide-react';
import Card from '../components/Card';

export default function Privacy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Privacy & Security</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl p-6 text-white text-center shadow-xl">
          <div className="inline-block p-4 bg-white/20 backdrop-blur-sm rounded-2xl mb-4">
            <Shield className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Your Privacy Matters</h2>
          <p className="text-blue-50">We're committed to protecting your personal information</p>
        </div>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">Information We Collect</h3>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Account information (name, email, phone number)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Photos you upload for AI generation</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Usage data and preferences</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Payment and transaction information</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">How We Use Your Data</h3>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Provide and improve our AI services</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Process transactions and payments</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Send important updates and notifications</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Enhance user experience and personalization</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">Data Security</h3>
          <p className="text-gray-700 leading-relaxed mb-3">
            We use industry-standard encryption and security measures to protect your personal information. Your photos and data are stored securely and never shared with third parties without your consent.
          </p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>256-bit SSL encryption</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Secure cloud storage</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 mt-1">•</span>
              <span>Regular security audits</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-gray-800 mb-3">Your Rights</h3>
          <p className="text-gray-700 leading-relaxed">
            You have the right to access, update, or delete your personal information at any time. Contact our support team for assistance with privacy-related requests.
          </p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-gray-50 to-gray-100">
          <p className="text-gray-600 text-sm text-center">
            Last updated: May 8, 2026
          </p>
        </Card>
      </div>
    </div>
  );
}
