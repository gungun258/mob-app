import { useNavigate } from 'react-router';
import { ChevronLeft, Package, Clock, CheckCircle, XCircle } from 'lucide-react';
import Card from '../components/Card';

const orders = [
  {
    id: 1,
    product: 'Sunset Beach Background',
    price: 15,
    date: 'May 7, 2026',
    status: 'completed',
  },
  {
    id: 2,
    product: 'Mountain Vista Background',
    price: 20,
    date: 'May 5, 2026',
    status: 'completed',
  },
  {
    id: 3,
    product: 'Urban Night Background',
    price: 12,
    date: 'May 3, 2026',
    status: 'refunded',
  },
  {
    id: 4,
    product: 'Pro Credit Package',
    price: 24.99,
    date: 'May 1, 2026',
    status: 'completed',
  },
];

export default function OrderHistory() {
  const navigate = useNavigate();

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-amber-500" />;
      case 'refunded':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Package className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'pending':
        return 'bg-amber-100 text-amber-700';
      case 'refunded':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-rose-50/30 to-white">
      <div className="sticky top-0 bg-white/80 backdrop-blur-xl border-b border-gray-100 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-xl">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-800">Order History</h1>
            <p className="text-sm text-gray-600">{orders.length} orders</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-3">
        {orders.map((order) => (
          <Card key={order.id} hoverable className="p-4">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 rounded-xl flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-gray-800 mb-1">{order.product}</h4>
                <p className="text-sm text-gray-600 mb-2">{order.date}</p>
                <div className="flex items-center gap-3">
                  <span className="text-rose-600 font-bold">${order.price}</span>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(
                      order.status
                    )}`}
                  >
                    {getStatusIcon(order.status)}
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </span>
                </div>
              </div>
              {order.status === 'completed' && (
                <button
                  onClick={() => navigate(`/refund/${order.id}`)}
                  className="text-sm text-gray-600 hover:text-gray-800 font-medium"
                >
                  Request Refund
                </button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
