import { Outlet, useLocation, useNavigate } from 'react-router';
import { Home, Compass, Sparkles, Image, User } from 'lucide-react';

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();

  const tabs = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/discover', icon: Compass, label: 'Discover' },
    { path: '/generate', icon: Sparkles, label: 'Generate' },
    { path: '/my-generations', icon: Image, label: 'Gallery' },
    { path: '/account', icon: User, label: 'Account' },
  ];

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-b from-white via-rose-50/30 to-white">
      <main className="flex-1 overflow-y-auto pb-20">
        <Outlet />
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-rose-100/50 shadow-[0_-4px_20px_rgba(0,0,0,0.03)]">
        <div className="max-w-md mx-auto px-4 py-2">
          <div className="flex items-center justify-around">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const active = isActive(tab.path);

              return (
                <button
                  key={tab.path}
                  onClick={() => navigate(tab.path)}
                  className={`flex flex-col items-center gap-1 py-2 px-4 rounded-2xl transition-all ${
                    active
                      ? 'text-rose-500'
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <div className={`p-2 rounded-xl transition-all ${
                    active
                      ? 'bg-gradient-to-br from-rose-100 to-pink-100 shadow-sm'
                      : 'bg-transparent'
                  }`}>
                    <Icon className="w-5 h-5" strokeWidth={active ? 2.5 : 2} />
                  </div>
                  <span className={`text-xs font-medium ${active ? 'opacity-100' : 'opacity-0'}`}>
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}
