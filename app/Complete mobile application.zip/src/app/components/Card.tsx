import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  hoverable?: boolean;
}

export default function Card({ children, onClick, className = '', hoverable = false }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-3xl shadow-sm border border-gray-100 ${
        hoverable ? 'hover:shadow-md hover:scale-[1.02] cursor-pointer' : ''
      } transition-all duration-200 ${className}`}
    >
      {children}
    </div>
  );
}
