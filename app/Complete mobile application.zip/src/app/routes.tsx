import { createBrowserRouter } from "react-router";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Discover from "./pages/Discover";
import AllSellers from "./pages/AllSellers";
import Generate from "./pages/Generate";
import MyGenerations from "./pages/MyGenerations";
import Account from "./pages/Account";
import Splash from "./pages/auth/Splash";
import Onboarding from "./pages/auth/Onboarding";
import Signup from "./pages/auth/Signup";
import Login from "./pages/auth/Login";
import OTPVerification from "./pages/auth/OTPVerification";
import ResetPassword from "./pages/auth/ResetPassword";
import ChangePassword from "./pages/auth/ChangePassword";
import ProductDetails from "./pages/ProductDetails";
import UploadUserPhoto from "./pages/generate/UploadUserPhoto";
import UploadBackground from "./pages/generate/UploadBackground";
import SelectStyle from "./pages/generate/SelectStyle";
import AIProcessing from "./pages/generate/AIProcessing";
import ResultScreen from "./pages/generate/ResultScreen";
import EditProfile from "./pages/account/EditProfile";
import Wishlist from "./pages/account/Wishlist";
import Referrals from "./pages/account/Referrals";
import SellerDashboard from "./pages/seller/SellerDashboard";
import PostAd from "./pages/seller/PostAd";
import EditAd from "./pages/seller/EditAd";
import SellerProfile from "./pages/seller/SellerProfile";
import Credits from "./pages/credits/Credits";
import BuyPackages from "./pages/credits/BuyPackages";
import CreditHistory from "./pages/credits/CreditHistory";
import Notifications from "./pages/Notifications";
import Settings from "./pages/Settings";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import FAQ from "./pages/FAQ";
import Support from "./pages/Support";
import OrderHistory from "./pages/OrderHistory";
import RefundRequest from "./pages/RefundRequest";

export const router = createBrowserRouter([
  {
    path: "/splash",
    Component: Splash,
  },
  {
    path: "/onboarding",
    Component: Onboarding,
  },
  {
    path: "/signup",
    Component: Signup,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/verify-otp",
    Component: OTPVerification,
  },
  {
    path: "/reset-password",
    Component: ResetPassword,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "discover", Component: Discover },
      { path: "sellers", Component: AllSellers },
      { path: "generate", Component: Generate },
      { path: "my-generations", Component: MyGenerations },
      { path: "account", Component: Account },
      { path: "product/:id", Component: ProductDetails },
      { path: "upload-photo", Component: UploadUserPhoto },
      { path: "upload-background", Component: UploadBackground },
      { path: "select-style", Component: SelectStyle },
      { path: "ai-processing", Component: AIProcessing },
      { path: "result/:id", Component: ResultScreen },
      { path: "edit-profile", Component: EditProfile },
      { path: "wishlist", Component: Wishlist },
      { path: "referrals", Component: Referrals },
      { path: "change-password", Component: ChangePassword },
      { path: "seller-dashboard", Component: SellerDashboard },
      { path: "post-ad", Component: PostAd },
      { path: "edit-ad/:id", Component: EditAd },
      { path: "seller/:id", Component: SellerProfile },
      { path: "credits", Component: Credits },
      { path: "buy-packages", Component: BuyPackages },
      { path: "credit-history", Component: CreditHistory },
      { path: "notifications", Component: Notifications },
      { path: "settings", Component: Settings },
      { path: "privacy", Component: Privacy },
      { path: "terms", Component: Terms },
      { path: "faq", Component: FAQ },
      { path: "support", Component: Support },
      { path: "orders", Component: OrderHistory },
      { path: "refund/:id", Component: RefundRequest },
    ],
  },
]);
