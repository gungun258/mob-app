Design a complete modern mobile app UI/UX for an AI-powered apply background to photo marketplace application. 
The app allows users to:
•	Upload a source photo on which background has to be applied
•	Upload a background photo 
•	Generate realistic AI images 
•	Buy background images from sellers 
•	Sell background photos through listings 
•	Use credits/subscriptions for AI generations 
•	Manage orders, refunds, referrals, and notifications 
The platform combines:
•	Images ecommerce marketplace 
•	Trending images discovery 
•	Premium AI experience 
DESIGN STYLE
•	Modern, elegant, premium mobile app UI 
•	Light theme only (NO dark mode) 
•	Fashion-tech startup aesthetic 
•	Minimal but visually rich 
•	Clean luxury interface 
•	Soft rounded corners 
•	Beautiful spacing and typography 
•	Soft gradients and premium shadows 
•	High-end AI product design 
•	Similar quality to: 
o	Airbnb 
o	Pinterest 
o	Zara 
o	Instagram 
o	ASOS 
o	modern AI apps 
COLOR PALETTE
Use:
•	Soft white backgrounds 
•	Warm beige 
•	Cream 
•	Soft lavender 
•	Blush pink 
•	Champagne gold accents 
•	Elegant pastel gradients 
Avoid:
•	Neon colors 
•	Heavy dark UI 
•	Cartoonish visuals 
TYPOGRAPHY
•	Modern sans-serif fonts 
•	Elegant visual hierarchy 
•	Minimal clutter 
•	Premium startup look 
APP MODULES & REQUIRED SCREENS
________________________________________
AUTHENTICATION & USER AUTHORIZATION
Splash Screen
•	Animated premium logo 
•	AI + fashion branding 
•	Elegant loading animation 
Onboarding Screens
Explain:
•	Upload your photo 
•	Upload background photo 
•	AI generates realistic photo combining both 
•	Buy & sell background photos 
•	Earn rewards through referrals 
Include:
•	Beautiful fashion illustrations 
•	Clean CTA buttons 
•	Swipe onboarding flow 
User Signup
•	Email signup 
•	Phone signup 
•	Google login 
•	Elegant modern auth UI 
User Login
•	Email/password 
•	OTP login 
•	Social login 
•	Remember me 
OTP Verification
Design screens for:
•	Email OTP 
•	WhatsApp OTP 
•	SMS OTP 
Reset Password
•	Forgot password 
•	OTP verification 
•	Create new password 
Change Password
•	Secure account settings UI 
User Logout
•	Elegant confirmation modal 
Delete Account
•	Safety confirmation flow 
•	Account deletion warnings 
________________________________________
ACCOUNT MANAGEMENT
User Profile
Include:
•	Profile photo 
•	Name 
•	Email 
•	Phone number 
•	Address 
•	Referral code 
•	Membership tier 
•	Credits balance 
Edit Profile
•	Editable modern form UI 
Wishlist
•	Saved products 
•	Grid gallery layout 
Referral System
Include:
•	Invite friends 
•	Referral code 
•	Earnings/rewards 
•	Referral progress tracker 
•	Social sharing options 
________________________________________
HOME & DISCOVERY
Home Dashboard
Include:
•	Upload user photo card 
•	Upload background image card 
•	“Generate Photo” CTA 
•	Trending backgrounds 
•	Recommended products 
•	AI suggestions 
•	Recently viewed items 
•	Seller highlights 
•	Credits balance widget 
Search Ads
Include:
•	Smart search bar 
•	Filters: 
o	category 
o	price 
•	Trending searches 
Listings Feed
•	ecommerce feed 
•	Beautiful product cards 
•	Infinite scroll 
•	Like/save options 
Display Ad / Product Details
Include:
•	Product gallery 
•	Seller profile 
•	Price 
•	Description 
•	AI Try button 
•	Wishlist 
•	Reviews 
•	Similar products 
•	Contact to Buy now 
________________________________________
AI generate image EXPERIENCE
Upload User Photo
•	Camera/gallery upload 
•	Photo guidelines 
Upload Outfit Photo
•	Background image upload 
AI Processing Screen
•	Premium loading animation 
•	AI generation progress 
•	motion design 
Result Screen
Include:
•	Before vs after comparison 
•	Swipe slider 
•	HD preview 
•	Save image 
•	Share 
•	Download 
•	Regenerate 
•	Add to wishlist 
•	Buy CTA 
My AI generations
•	Generated looks gallery 
•	Collections 
•	Favorites 
•	Search 
________________________________________
SELLER AD MANAGEMENT
Seller Dashboard
Include:
•	Active listings 
•	Sales analytics 
•	Earnings summary 
•	Orders overview 
•	Performance charts 
Post Ad
Include:
•	Upload product photos 
•	Product details form 
•	Pricing 
•	Category selection 
•	Shipping options 
Edit Ad
•	Editable listing management 
Delete Ad
•	Confirmation modal 
•	Warning state 
Seller Profile
Include:
•	Seller rating 
•	Followers 
•	Product count 
•	Reviews 
•	Verified badge 
________________________________________
AI CREDITS HISTORY MANAGEMENT
Include:
•	Credits usage 
•	Coupon codes redemption
•	CREDITS PURCHASE summary 
Order Dispute / Refund Request
Include:
•	Reason selection 
•	Upload proof 
•	Chat support 
•	Refund tracking 
Refund Status
•	Timeline progress UI 
________________________________________
CREDITS
Credits Dashboard
Include:
•	Current credits 
•	Usage stats 
•	Remaining generations 
Buyer Packages
Design:
•	Monthly plans 
•	Premium plans 
•	AI credits packs 
•	Subscription comparison cards 
Free Credits
•	Daily rewards 
•	Referral rewards 
•	Promotional bonuses 
Credit History
Include:
•	Purchases 
•	Usage 
•	Refunds 
•	Rewards history 
Refunds
•	Refund request list 
•	Approved/rejected states 
________________________________________
NOTIFICATIONS
Notification Panel
Include:
•	AI generation updates 
•	Refund updates 
•	Referral rewards 
•	Promotions 
Push Notification Preview Screens
Email Notification Templates
WhatsApp Notification UI
________________________________________
EXTRA REQUIRED SCREENS
Favorites / Saved Looks
Settings
Privacy & Security
Terms & Conditions
FAQs
Contact Support
Empty States
Error States
Success States
Loading Skeleton Screens
________________________________________
NAVIGATION
Use:
•	Bottom tab navigation 
•	Floating action buttons 
•	Gesture-friendly UX 
•	Smooth page transitions 
Bottom tabs:
•	Home 
•	Explore 
•	Generate AI image
•	My generations
•	Account 
________________________________________
UI COMPONENT REQUIREMENTS
Create:
•	Full design system 
•	Reusable components 
•	Buttons 
•	Input fields 
•	Cards 
•	Modals 
•	Bottom sheets 
•	Product grids 
•	Pricing cards 
•	Charts 
•	Notification cards 
________________________________________
VISUAL QUALITY
•	App Store-ready quality 
•	High-fidelity UI screens 
•	Consistent spacing system 
•	Premium startup-level aesthetics 
•	Realistic mobile mockups 
•	Production-ready design quality 
Generate:
•	Complete mobile app UI system 
•	Multiple app screens 
•	Modern interactions 
•	Realistic ecommerce + AI fashion experience 
•	Beautiful polished mobile app designs for iOS and Android.

